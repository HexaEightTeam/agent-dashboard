#!/bin/bash

# HexaEight Copilot Startup Script with Integrated Bridge
# =======================================================

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Cleanup function
cleanup() {
    log_info "🛑 Shutting down services..."
    
    # Stop bridge if running
    if [ -f "bridge/stop_bridge.sh" ]; then
        log_info "Stopping HexaEight Bridge..."
        cd bridge && ./stop_bridge.sh && cd ..
    fi
    
    # Stop Next.js server
    if [ ! -z "$NEXTJS_PID" ]; then
        log_info "Stopping Next.js server..."
        kill $NEXTJS_PID 2>/dev/null || true
    fi
    
    log_success "✅ All services stopped"
    exit 0
}

# Set up signal handlers
trap cleanup SIGINT SIGTERM

# Check if .env file exists
if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        log_warn "⚠️  .env file not found. Creating from .env.example"
        cp .env.example .env
        log_warn "Please edit .env file with your configuration before running again."
        exit 1
    else
        log_error "❌ No environment configuration found."
        log_error "Please create a .env file with your HexaEight configuration."
        exit 1
    fi
fi

# Set defaults for Node.js runtime
export NODE_ENV=${NODE_ENV:-production}
export PORT=${PORT:-3000}
export HOSTNAME=${HOSTNAME:-0.0.0.0}

log_info "🚀 Starting HexaEight Copilot with integrated Bridge..."

# Start HexaEight Bridge if available
BRIDGE_STARTED=false
if [ -f "bridge/start_bridge.sh" ] && [ -f "bridge/hexaeight_centralized_bridge.py" ]; then
    log_info "🌉 Starting HexaEight Bridge on localhost:8000..."
    cd bridge
    ./start_bridge.sh &
    BRIDGE_PID=$!
    cd ..
    
    # Wait a moment for bridge to start
    sleep 2
    
    # Check if bridge started successfully
    if kill -0 $BRIDGE_PID 2>/dev/null; then
        log_success "✅ HexaEight Bridge started (PID: $BRIDGE_PID)"
        BRIDGE_STARTED=true
        export HEXAEIGHT_BRIDGE_URL="http://127.0.0.1:8000"
    else
        log_warn "⚠️  Bridge failed to start, continuing without it"
    fi
else
    log_warn "⚠️  Bridge files not found, running without integrated bridge"
fi

# Check if HEXAEIGHT_BRIDGE_URL is configured
BRIDGE_URL_CHECK=$(grep "^HEXAEIGHT_BRIDGE_URL=" .env 2>/dev/null | cut -d'=' -f2- | tr -d '"' | tr -d "'")
if [ -z "$BRIDGE_URL_CHECK" ] && [ "$BRIDGE_STARTED" = true ]; then
    log_info "✅ Using integrated bridge: http://127.0.0.1:8000"
elif [ ! -z "$BRIDGE_URL_CHECK" ]; then
    log_info "✅ Using external bridge: $BRIDGE_URL_CHECK"
else
    log_warn "⚠️  No bridge URL configured"
fi

log_info "📍 Next.js server will be available at: http://${HOSTNAME}:${PORT}"

# Start Next.js server
node server.js &
NEXTJS_PID=$!

log_success "✅ HexaEight Copilot started successfully"
log_info "📋 Services running:"
if [ "$BRIDGE_STARTED" = true ]; then
    log_info "  • HexaEight Bridge: http://127.0.0.1:8000 (PID: $BRIDGE_PID)"
fi
log_info "  • Next.js Application: http://${HOSTNAME}:${PORT} (PID: $NEXTJS_PID)"

# Wait for Next.js process
wait $NEXTJS_PID
