# HexaEight Copilot - Standalone Deployment with Integrated Bridge

This is a self-contained Next.js application build with integrated HexaEight Bridge that can be deployed on any system with Node.js and Python 3.

## System Requirements

- Node.js 18.x or higher
- Python 3.8+ with venv support
- At least 1GB RAM (for both Next.js and Bridge)
- Network access (Bridge runs on localhost:8000)

## Quick Start

### 1. Install Dependencies
Make sure Node.js and Python 3 are installed on your target system:
```bash
# Check if Node.js is installed
node --version
npm --version

# Check if Python 3 is installed
python3 --version
python3 -m venv --help

# Install Python venv if needed (Ubuntu/Debian)
sudo apt install python3-venv
```

### 2. Configure Environment
```bash
# Copy the environment template
cp .env.example .env

# Edit the configuration
nano .env  # or your preferred editor
```

Required configuration (integrated bridge will use localhost:8000 automatically):
```env
# Optional: External bridge URL (leave empty to use integrated bridge)
HEXAEIGHT_BRIDGE_URL=

# Next.js Configuration
PORT=3000
NODE_ENV=production
```

### 3. Start the Application

The startup script will automatically:
- Start the integrated HexaEight Bridge on localhost:8000
- Start the Next.js application on port 3000
- Handle graceful shutdown of both services

**Linux/macOS:**
```bash
# Make executable and run
chmod +x start.sh
./start.sh
```

**Windows:**
```cmd
start.bat
```

**Manual Start:**
```bash
node server.js
```

## Application Access

Once started, the application will be available at:
- Local: http://localhost:3000
- Network: http://your-server-ip:3000

## Configuration Options

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `HEXAEIGHT_BRIDGE_URL` | (required) | URL of the HexaEight Bridge server |
| `PORT` | 3000 | Port number for the web server |
| `HOSTNAME` | 0.0.0.0 | Hostname to bind to (0.0.0.0 for all interfaces) |
| `NODE_ENV` | production | Node.js environment mode |

### Network Configuration

To allow external access, make sure:
1. The port (default 3000) is not blocked by firewall
2. The bridge server URL is accessible from this machine
3. Set `HOSTNAME=0.0.0.0` to accept connections from any IP

## Troubleshooting

### Common Issues

**"Cannot connect to bridge server"**
- Verify `HEXAEIGHT_BRIDGE_URL` is correct and accessible
- Check network connectivity: `curl $HEXAEIGHT_BRIDGE_URL/health`

**"Port already in use"**
- Change the `PORT` in .env file
- Kill existing process: `lsof -ti:3000 | xargs kill`

**"Permission denied"**
- Make sure start.sh is executable: `chmod +x start.sh`
- Run as a user with appropriate permissions

### Logs

Application logs will be displayed in the console. For persistent logging:
```bash
./start.sh > app.log 2>&1 &
```

### Stopping the Application

- Press `Ctrl+C` if running in foreground
- Kill the process: `pkill -f "node server.js"`

## Advanced Deployment

### As a System Service (Linux)

Create a systemd service file:
```bash
sudo nano /etc/systemd/system/hexaeight-copilot.service
```

```ini
[Unit]
Description=HexaEight Copilot
After=network.target

[Service]
Type=simple
User=hexaeight
WorkingDirectory=/opt/hexaeight-copilot
ExecStart=/usr/bin/node server.js
Restart=on-failure
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable hexaeight-copilot
sudo systemctl start hexaeight-copilot
```

### Behind a Reverse Proxy (nginx)

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Support

For issues and support, refer to the HexaEight documentation or contact your system administrator.
