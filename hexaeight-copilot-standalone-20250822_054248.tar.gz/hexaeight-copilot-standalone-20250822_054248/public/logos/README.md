# Logo Directory

Place your custom logo files here for white-label customization.

## Supported Formats
- PNG (recommended)
- JPG/JPEG
- SVG

## Recommended Specifications
- Size: 256x256px or larger (square format works best)
- Background: Transparent (for PNG files)
- Format: PNG for best compatibility

## Configuration
Update your .env.local file:
```
NEXT_PUBLIC_LOGO_URL="/logos/your-logo.png"
```

## Fallback
If the logo file is not found, the system will use the icon specified in:
```
NEXT_PUBLIC_LOGO_FALLBACK_ICON="Rocket"
```

Available fallback icons: Rocket, Shield, Zap, Network, Users, Brain, Bot, Lock, Globe, Layers, MessageSquare, Settings
