#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[BRIDGE]${NC} $1"; }
log_success() { echo -e "${GREEN}[BRIDGE]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[BRIDGE]${NC} $1"; }
log_error() { echo -e "${RED}[BRIDGE]${NC} $1"; }

# Check Python
if ! command -v python3 &> /dev/null; then
    log_error "❌ Python 3 not found. Please install Python 3"
    exit 1
fi

# Check venv support
if ! python3 -m venv --help &> /dev/null; then
    log_error "❌ Python venv not available. Install with: sudo apt install python3-venv"
    exit 1
fi

# Create virtual environment
VENV_DIR="./bridge_env"
if [ ! -d "$VENV_DIR" ]; then
    log_info "🐍 Creating bridge virtual environment..."
    python3 -m venv "$VENV_DIR"
    log_success "✅ Virtual environment created"
fi

# Install packages
log_info "📦 Installing bridge dependencies..."
"$VENV_DIR/bin/pip" install --upgrade pip
"$VENV_DIR/bin/pip" install hexaeight-mcp-client aiohttp aiohttp-cors

log_success "✅ Bridge environment ready"
