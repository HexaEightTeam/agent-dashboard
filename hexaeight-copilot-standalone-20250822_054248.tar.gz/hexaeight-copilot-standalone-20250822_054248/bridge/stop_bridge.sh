#!/bin/bash

# Colors for output
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[BRIDGE]${NC} $1"; }

log_info "🛑 Stopping HexaEight Bridge..."

# Kill bridge processes
pkill -f "python3 hexaeight_centralized_bridge.py" || true
pkill -f "hexaeight_centralized_bridge.py" || true

log_info "✅ Bridge stopped"
