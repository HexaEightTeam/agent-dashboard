#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[BRIDGE]${NC} $1"; }
log_success() { echo -e "${GREEN}[BRIDGE]${NC} $1"; }
log_error() { echo -e "${RED}[BRIDGE]${NC} $1"; }

# Change to bridge directory
cd "$(dirname "$0")"

# Check required files
if [ ! -f "hexaeight_centralized_bridge.py" ]; then
    log_error "❌ hexaeight_centralized_bridge.py not found"
    exit 1
fi

if [ ! -f "git_mcp_tool.py" ]; then
    log_error "❌ git_mcp_tool.py not found"
    exit 1
fi

# Setup environment if needed
if [ ! -d "bridge_env" ]; then
    log_info "🔧 Setting up bridge environment..."
    ./setup_bridge.sh
fi

# Check virtual environment
if [ ! -d "bridge_env" ]; then
    log_error "❌ Bridge environment setup failed"
    exit 1
fi

log_info "🚀 Starting HexaEight Bridge on localhost:8000..."
source bridge_env/bin/activate
export PYTHONPATH="${PYTHONPATH}:."

# Force bridge to localhost only - modify the bridge startup to bind to 127.0.0.1
exec python3 hexaeight_centralized_bridge.py --host 127.0.0.1 --port 8000
