#!/usr/bin/env python3
"""
HexaEight Mission-Enhanced Centralized Bridge System
===================================================

PRESERVES: All existing working functionality from hexaeight_centralized_bridge.py
ADDS: Mission-first API endpoints for dashboard compatibility

Key Changes:
- Keeps ALL existing working agent initialization 
- Keeps ALL existing message handling
- Adds mission management endpoints
- Adds mission-specific SSE streams
- Backward compatible with existing chat endpoints
- FIXES: camelCase responses, context proposals, real git operations

Version: Enhanced from working bridge
"""

import asyncio
import json
import os
import sys
import uuid
import hashlib
import logging
import signal
import re
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any, Set
from dataclasses import dataclass, asdict
import argparse
from collections import defaultdict

# HTTP/SSE Server
from aiohttp import web, WSMsgType
import aiohttp_cors

from hexaeight_mcp_client import quick_autogen_llm, HexaEightLLMAgent
from git_mcp_tool import GitMCPTool, GitFileOperation

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(name)s | %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

class BridgeLogger:
    """Enhanced logging and monitoring for bridge"""
    
    # Class-level metrics storage
    metrics = {
        "requests_total": 0,
        "requests_by_endpoint": {},
        "errors_total": 0,
        "errors_by_type": {},
        "missions_created": 0,
        "missions_by_status": {},
        "messages_sent": 0,
        "messages_by_mission": {},
        "git_operations": 0,
        "git_errors": 0,
        "performance_metrics": {
            "avg_response_time_ms": 0,
            "request_times": []
        },
        "start_time": datetime.now(),
        "last_reset": datetime.now()
    }
    
    @staticmethod
    def log_system(message: str, bridge_id: str = "MAIN", level: str = "INFO"):
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        icon = {"INFO": "🌉", "WARNING": "⚠️", "ERROR": "❌", "DEBUG": "🔍"}.get(level, "🌉")
        print(f"\n{icon} [{timestamp}] {bridge_id} | {level} | {message}")
        
        # Track error metrics
        if level == "ERROR":
            BridgeLogger.metrics["errors_total"] += 1
            error_type = bridge_id.lower()
            BridgeLogger.metrics["errors_by_type"][error_type] = BridgeLogger.metrics["errors_by_type"].get(error_type, 0) + 1
    
    @staticmethod
    def log_http_request(method: str, path: str, user_email: str = "unknown", response_time_ms: float = None):
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        print(f"\n🌐 [{timestamp}] HTTP {method} {path}")
        print(f"   └─ User: {user_email}")
        
        if response_time_ms:
            print(f"   └─ Time: {response_time_ms:.1f}ms")
            # Track performance metrics
            BridgeLogger.metrics["performance_metrics"]["request_times"].append(response_time_ms)
            # Keep only last 1000 requests for average calculation
            if len(BridgeLogger.metrics["performance_metrics"]["request_times"]) > 1000:
                BridgeLogger.metrics["performance_metrics"]["request_times"] = BridgeLogger.metrics["performance_metrics"]["request_times"][-1000:]
            
            # Update average response time
            times = BridgeLogger.metrics["performance_metrics"]["request_times"]
            BridgeLogger.metrics["performance_metrics"]["avg_response_time_ms"] = sum(times) / len(times)
        
        # Track request metrics
        BridgeLogger.metrics["requests_total"] += 1
        endpoint_key = f"{method} {path.split('?')[0]}"  # Remove query params for grouping
        BridgeLogger.metrics["requests_by_endpoint"][endpoint_key] = BridgeLogger.metrics["requests_by_endpoint"].get(endpoint_key, 0) + 1
    
    @staticmethod
    def log_message_flow(direction: str, user_email: str, content: str, msg_id: str, mission_id: str = None):
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        user_short = user_email.split('@')[0] if '@' in user_email else user_email[:10]
        content_preview = content[:50].replace('\n', ' ')
        
        mission_info = f" [Mission: {mission_id}]" if mission_id else ""
        print(f"\n📨 [{timestamp}] {direction} {user_short} ({msg_id}){mission_info}: {content_preview}...")
        
        # Track message metrics
        if direction == "→ OUT":
            BridgeLogger.metrics["messages_sent"] += 1
            if mission_id:
                BridgeLogger.metrics["messages_by_mission"][mission_id] = BridgeLogger.metrics["messages_by_mission"].get(mission_id, 0) + 1
    
    @staticmethod
    def log_mission_event(event_type: str, mission_id: str, details: str = "", status: str = None):
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        icons = {
            "created": "🎯",
            "updated": "📝", 
            "archived": "📦",
            "deleted": "🗑️",
            "agent_assigned": "👤",
            "agent_removed": "👤❌",
            "message_added": "💬",
            "proposal_created": "💡",
            "proposal_approved": "✅",
            "proposal_rejected": "❌"
        }
        icon = icons.get(event_type, "🎯")
        
        print(f"\n{icon} [{timestamp}] MISSION {event_type.upper()} | {mission_id}")
        if details:
            print(f"   └─ {details}")
        
        # Track mission metrics
        if event_type == "created":
            BridgeLogger.metrics["missions_created"] += 1
        
        if status:
            BridgeLogger.metrics["missions_by_status"][status] = BridgeLogger.metrics["missions_by_status"].get(status, 0) + 1
    
    @staticmethod
    def log_git_operation(operation: str, success: bool, details: str = "", commit_sha: str = None):
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        status_icon = "✅" if success else "❌"
        
        print(f"\n🔧 [{timestamp}] GIT {operation.upper()} {status_icon}")
        if details:
            print(f"   └─ {details}")
        if commit_sha:
            print(f"   └─ Commit: {commit_sha}")
        
        # Track Git metrics
        BridgeLogger.metrics["git_operations"] += 1
        if not success:
            BridgeLogger.metrics["git_errors"] += 1
    
    @staticmethod
    def log_performance_warning(operation: str, duration_ms: float, threshold_ms: float = 1000):
        """Log performance warnings for slow operations"""
        if duration_ms > threshold_ms:
            timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
            print(f"\n⚡ [{timestamp}] PERF WARNING | {operation} took {duration_ms:.1f}ms (threshold: {threshold_ms}ms)")
    
    @staticmethod
    def get_metrics_summary():
        """Get comprehensive metrics summary"""
        uptime = datetime.now() - BridgeLogger.metrics["start_time"]
        uptime_str = str(uptime).split('.')[0]  # Remove microseconds
        
        return {
            "uptime": uptime_str,
            "requests": {
                "total": BridgeLogger.metrics["requests_total"],
                "by_endpoint": dict(sorted(BridgeLogger.metrics["requests_by_endpoint"].items(), key=lambda x: x[1], reverse=True)),
                "avg_response_time_ms": round(BridgeLogger.metrics["performance_metrics"]["avg_response_time_ms"], 1)
            },
            "errors": {
                "total": BridgeLogger.metrics["errors_total"],
                "by_type": dict(sorted(BridgeLogger.metrics["errors_by_type"].items(), key=lambda x: x[1], reverse=True)),
                "error_rate": round(BridgeLogger.metrics["errors_total"] / max(BridgeLogger.metrics["requests_total"], 1) * 100, 2)
            },
            "missions": {
                "created": BridgeLogger.metrics["missions_created"],
                "by_status": BridgeLogger.metrics["missions_by_status"]
            },
            "messages": {
                "sent": BridgeLogger.metrics["messages_sent"],
                "by_mission": dict(sorted(BridgeLogger.metrics["messages_by_mission"].items(), key=lambda x: x[1], reverse=True)[:10])  # Top 10
            },
            "git": {
                "operations": BridgeLogger.metrics["git_operations"],
                "errors": BridgeLogger.metrics["git_errors"],
                "success_rate": round((BridgeLogger.metrics["git_operations"] - BridgeLogger.metrics["git_errors"]) / max(BridgeLogger.metrics["git_operations"], 1) * 100, 2)
            },
            "last_reset": BridgeLogger.metrics["last_reset"].isoformat(),
            "generated_at": datetime.now().isoformat()
        }
    
    @staticmethod
    def reset_metrics():
        """Reset all metrics"""
        BridgeLogger.metrics = {
            "requests_total": 0,
            "requests_by_endpoint": {},
            "errors_total": 0,
            "errors_by_type": {},
            "missions_created": 0,
            "missions_by_status": {},
            "messages_sent": 0,
            "messages_by_mission": {},
            "git_operations": 0,
            "git_errors": 0,
            "performance_metrics": {
                "avg_response_time_ms": 0,
                "request_times": []
            },
            "start_time": BridgeLogger.metrics["start_time"],  # Keep original start time
            "last_reset": datetime.now()
        }

# =====================================================================================
# PRESERVED: All original data structures
# =====================================================================================

@dataclass
class UserContext:
    """User context for message routing"""
    user_id: str
    user_email: str
    session_id: str
    created_at: str
    last_activity: str

@dataclass
class BridgeMessage:
    """Message being processed by bridge"""
    msg_id: str
    user_context: UserContext
    content: str
    timestamp: str
    status: str = 'pending'
    bridge_id: str = 'bridge'

# =====================================================================================
# NEW: Mission data structures
# =====================================================================================

@dataclass
class MissionData:
    """Mission data structure"""
    id: str
    title: str
    description: str
    status: str  # planning, active, completed, archived
    created_at: str
    last_activity: str
    assigned_agents: List[str]
    user_hash: str
    context: Dict[str, Any]

@dataclass
class ContextProposal:
    """Context proposal structure"""
    proposal_id: str
    message_id: str
    mission_id: str
    orchestrator_id: str
    changes: Dict[str, Any]
    reason: str
    created_at: str
    status: str  # pending, approved, rejected
    processed_at: Optional[str] = None

# =====================================================================================
# NEW: Utility Functions
# =====================================================================================

class CamelCaseConverter:
    """Convert between snake_case and camelCase"""
    
    @staticmethod
    def to_camel_case(snake_str: str) -> str:
        """Convert snake_case to camelCase"""
        components = snake_str.split('_')
        return components[0] + ''.join(word.capitalize() for word in components[1:])
    
    @staticmethod
    def convert_keys_to_camel_case(obj):
        """Recursively convert all keys in object to camelCase"""
        if isinstance(obj, dict):
            return {CamelCaseConverter.to_camel_case(k): CamelCaseConverter.convert_keys_to_camel_case(v) 
                   for k, v in obj.items()}
        elif isinstance(obj, list):
            return [CamelCaseConverter.convert_keys_to_camel_case(item) for item in obj]
        return obj

# =====================================================================================
# NEW: Context Proposal Manager
# =====================================================================================

class ContextProposalManager:
    """Manage context proposals from orchestrators"""
    
    def __init__(self, missions_base_path: Path):
        self.missions_base_path = missions_base_path
        self.context_update_lock = asyncio.Lock()  # CRITICAL: Bridge exclusive lock
        self.pending_proposals: Dict[str, ContextProposal] = {}
    
    async def create_proposal(self, mission_id: str, message_id: str, orchestrator_id: str,
                            changes: dict, reason: str) -> str:
        """Create a new context proposal"""
        proposal_id = f"prop_{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}"
        
        proposal = ContextProposal(
            proposal_id=proposal_id,
            message_id=message_id,
            mission_id=mission_id,
            orchestrator_id=orchestrator_id,
            changes=changes,
            reason=reason,
            created_at=datetime.now().isoformat(),
            status="pending"
        )
        
        # Save proposal to disk
        proposal_path = self.missions_base_path / mission_id / "proposals" / f"{proposal_id}.json"
        proposal_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(proposal_path, 'w') as f:
            json.dump(asdict(proposal), f, indent=2)
        
        self.pending_proposals[proposal_id] = proposal
        BridgeLogger.log_system(f"📋 Context proposal created: {proposal_id}", "PROPOSAL")
        
        return proposal_id
    
    async def get_proposals(self, mission_id: str) -> List[dict]:
        """Get all proposals for a mission"""
        proposals = []
        proposals_dir = self.missions_base_path / mission_id / "proposals"
        
        if not proposals_dir.exists():
            return proposals
        
        for proposal_file in proposals_dir.glob("*.json"):
            try:
                with open(proposal_file, 'r') as f:
                    proposal_data = json.load(f)
                proposals.append(proposal_data)
            except Exception as e:
                BridgeLogger.log_system(f"⚠️ Error loading proposal {proposal_file}: {e}", "PROPOSAL", "WARNING")
        
        # Sort by created_at descending
        proposals.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        return proposals
    
    async def process_user_approval(self, mission_id: str, proposal_id: str, approved: bool) -> bool:
        """Process user approval/rejection of context proposal"""
        
        # CRITICAL: Bridge exclusive context update lock
        async with self.context_update_lock:
            try:
                # Load proposal
                proposal_path = self.missions_base_path / mission_id / "proposals" / f"{proposal_id}.json"
                
                if not proposal_path.exists():
                    BridgeLogger.log_system(f"❌ Proposal not found: {proposal_id}", "PROPOSAL", "ERROR")
                    return False
                
                with open(proposal_path, 'r') as f:
                    proposal_data = json.load(f)
                
                if approved:
                    # Load current context
                    context_path = self.missions_base_path / mission_id / "context.json"
                    
                    if not context_path.exists():
                        BridgeLogger.log_system(f"❌ Context not found: {mission_id}", "PROPOSAL", "ERROR")
                        return False
                    
                    with open(context_path, 'r') as f:
                        current_context = json.load(f)
                    
                    # Apply changes
                    updated_context = self._apply_proposal_changes(current_context, proposal_data['changes'])
                    updated_context['last_activity'] = datetime.now().isoformat()
                    
                    # Save updated context
                    with open(context_path, 'w') as f:
                        json.dump(updated_context, f, indent=2)
                    
                    # Update proposal status
                    proposal_data['status'] = 'approved'
                    proposal_data['processed_at'] = datetime.now().isoformat()
                    
                    BridgeLogger.log_system(f"✅ Context proposal approved and applied: {proposal_id}", "PROPOSAL")
                else:
                    proposal_data['status'] = 'rejected'
                    proposal_data['processed_at'] = datetime.now().isoformat()
                    
                    BridgeLogger.log_system(f"❌ Context proposal rejected: {proposal_id}", "PROPOSAL")
                
                # Save updated proposal
                with open(proposal_path, 'w') as f:
                    json.dump(proposal_data, f, indent=2)
                
                return True
                
            except Exception as e:
                BridgeLogger.log_system(f"❌ Proposal processing error: {e}", "PROPOSAL", "ERROR")
                return False
    
    def _apply_proposal_changes(self, context: dict, changes: dict) -> dict:
        """Apply proposal changes to context"""
        updated_context = context.copy()
        
        # Apply changes recursively
        for key, value in changes.items():
            if isinstance(value, dict) and key in updated_context and isinstance(updated_context[key], dict):
                # Merge dictionaries
                updated_context[key].update(value)
            else:
                # Direct assignment
                updated_context[key] = value
        
        return updated_context

# =====================================================================================
# NEW: Mission Manager
# =====================================================================================

class MissionManager:
    """Manage missions and their lifecycle"""
    
    def __init__(self, missions_base_path: Path, hexaeight_agent=None):
        self.missions_base_path = missions_base_path
        self.missions_base_path.mkdir(exist_ok=True)
        self.active_missions: Dict[str, MissionData] = {}
        
        # Initialize Git MCP Tool if agent is available
        self.git_tool = None
        self.git_stats = {
            "commits_attempted": 0,
            "commits_successful": 0,
            "commits_failed": 0,
            "fallback_saves": 0
        }
        
        if hexaeight_agent:
            try:
                self.git_tool = GitMCPTool(hexaeight_agent)
                print("✅ Git MCP tool initialized for mission storage")
            except Exception as e:
                print(f"⚠️ Git MCP tool initialization failed: {e}")
                print("   Missions will be stored locally without git commits")
    
    async def _initialize_git_repository(self):
        """Initialize git repository for mission storage"""
        try:
            if self.git_tool:
                await self.git_tool.initialize()
                
                # Create repository if it doesn't exist
                repo_name = "hexaeight-missions"
                create_result = await self.git_tool.create_repository(repo_name, initial_commit=True)
                
                if create_result.get("isSuccessful"):
                    self.git_initialized = True
                    BridgeLogger.log_system(f"✅ Git repository initialized: {repo_name}")
                else:
                    BridgeLogger.log_system(f"⚠️ Git repository creation failed: {create_result.get('errorMessage', 'Unknown error')}")
                    
        except Exception as e:
            BridgeLogger.log_system(f"⚠️ Git initialization failed: {e}")
    
    # NEW: Enhanced Git operations with fallback (SAFE ADDITIONS)
    async def _save_files_with_git_fallback(self, mission_id: str, git_files: List[GitFileOperation], 
                                          commit_message: str) -> dict:
        """
        SAFE: Enhanced Git saving with local fallback and detailed error handling
        Returns: {"success": bool, "method": "git"/"local", "details": {...}}
        """
        self.git_stats["commits_attempted"] += 1
        
        # Try Git commit first
        if self.git_tool:
            try:
                BridgeLogger.log_system(f"🔄 Attempting Git commit for mission {mission_id}: {len(git_files)} files")
                
                commit_result = await self.git_tool.commit_files(
                    git_files, 
                    commit_message,
                    repository=f"missions/{mission_id}"
                )
                
                if commit_result.get("isSuccessful"):
                    self.git_stats["commits_successful"] += 1
                    commit_sha = commit_result.get("commit_sha", "unknown")
                    BridgeLogger.log_system(f"✅ Git commit successful: {commit_sha}")
                    return {
                        "success": True,
                        "method": "git",
                        "commit_sha": commit_sha,
                        "files_count": len(git_files),
                        "details": commit_result
                    }
                else:
                    raise Exception(f"Git commit failed: {commit_result}")
                    
            except Exception as git_error:
                self.git_stats["commits_failed"] += 1
                BridgeLogger.log_system(f"⚠️ Git commit failed, using local fallback: {git_error}", 
                                      level="WARNING")
                
                # Fallback to local file saving
                return await self._save_files_locally_enhanced(mission_id, git_files, git_error)
        else:
            BridgeLogger.log_system("⚠️ Git tool not available, using local storage")
            return await self._save_files_locally_enhanced(mission_id, git_files, "Git tool not initialized")
    
    async def _save_files_locally_enhanced(self, mission_id: str, git_files: List[GitFileOperation], 
                                         reason: str) -> dict:
        """SAFE: Enhanced local file saving with error tracking"""
        try:
            self.git_stats["fallback_saves"] += 1
            mission_path = self.missions_base_path / mission_id
            files_saved = []
            
            for git_file in git_files:
                file_path = mission_path / git_file.path
                file_path.parent.mkdir(parents=True, exist_ok=True)
                
                with open(file_path, 'w') as f:
                    f.write(git_file.content)
                files_saved.append(str(file_path))
            
            BridgeLogger.log_system(f"✅ Local fallback save completed: {len(files_saved)} files")
            return {
                "success": True,
                "method": "local_fallback",
                "files_saved": files_saved,
                "reason": str(reason),
                "files_count": len(git_files)
            }
            
        except Exception as local_error:
            BridgeLogger.log_system(f"❌ Local fallback save failed: {local_error}", level="ERROR")
            return {
                "success": False,
                "method": "local_fallback_failed",
                "error": str(local_error),
                "reason": str(reason)
            }
    
    async def _verify_git_status(self, mission_id: str = None) -> dict:
        """SAFE: Check Git repository status without breaking anything"""
        try:
            status = {
                "git_tool_available": self.git_tool is not None,
                "git_initialized": hasattr(self, 'git_initialized') and getattr(self, 'git_initialized', False),
                "git_stats": self.git_stats.copy(),
                "missions_base_path": str(self.missions_base_path)
            }
            
            if mission_id:
                mission_path = self.missions_base_path / mission_id
                git_path = mission_path / ".git"
                status.update({
                    "mission_id": mission_id,
                    "mission_path_exists": mission_path.exists(),
                    "git_directory_exists": git_path.exists(),
                    "mission_path": str(mission_path)
                })
            
            if self.git_tool:
                try:
                    status["git_tool_initialized"] = hasattr(self.git_tool, 'agent_name')
                    status["git_server_url"] = getattr(self.git_tool, 'git_server_url', 'unknown')
                except Exception as e:
                    status["git_tool_error"] = str(e)
            
            return status
            
        except Exception as e:
            return {
                "error": str(e),
                "git_tool_available": False,
                "missions_base_path": str(self.missions_base_path)
            }
    
    async def create_mission(self, title: str, description: str, agent_ids: List[str], user_hash: str) -> MissionData:
        """Create a new mission"""
        mission_id = f"mission_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        
        mission_data = MissionData(
            id=mission_id,
            title=title,
            description=description,
            status="planning",
            created_at=datetime.now().isoformat(),
            last_activity=datetime.now().isoformat(),
            assigned_agents=agent_ids,
            user_hash=user_hash,
            context={
                "id": mission_id,
                "title": title,
                "description": description,
                "status": "planning",
                "created_at": datetime.now().isoformat(),
                "last_activity": datetime.now().isoformat(),
                "assigned_agents": {agent_id: "assigned" for agent_id in agent_ids},
                "subtasks": [],
                "user_hash": user_hash
            }
        )
        
        # Create mission directory structure
        mission_path = self.missions_base_path / mission_id
        mission_path.mkdir(exist_ok=True)
        (mission_path / "messages").mkdir(exist_ok=True)
        (mission_path / "responses").mkdir(exist_ok=True)
        (mission_path / "proposals").mkdir(exist_ok=True)
        
        # Save mission context
        context_file = mission_path / "context.json"
        with open(context_file, 'w') as f:
            json.dump(mission_data.context, f, indent=2)
        
        # Commit to git if available
        if self.git_tool:
            try:
                # Initialize git repository if needed
                if not hasattr(self, 'git_initialized'):
                    await self._initialize_git_repository()
                
                git_files = [
                    GitFileOperation(
                        path=f"missions/{mission_id}/context.json",
                        content=json.dumps(mission_data.context, indent=2),
                        operation="add"
                    )
                ]
                
                commit_result = await self.git_tool.commit_files(
                    git_files, 
                    f"[BRIDGE] Mission created: {mission_id} - {title}"
                )
                
                if commit_result.success:
                    BridgeLogger.log_system(f"✅ Mission committed to git: {commit_result.commit_sha}")
                else:
                    BridgeLogger.log_system(f"⚠️ Git commit failed: {commit_result.message}")
                    
            except Exception as e:
                BridgeLogger.log_system(f"⚠️ Git operation failed: {e}")
        
        self.active_missions[mission_id] = mission_data
        
        BridgeLogger.log_system(f"📋 Mission created: {mission_id} - {title}")
        return mission_data
    
    async def get_mission(self, mission_id: str) -> Optional[MissionData]:
        """Get mission by ID"""
        if mission_id in self.active_missions:
            return self.active_missions[mission_id]
        
        # Try to load from disk
        return await self._load_mission_from_disk(mission_id)
    
    async def list_user_missions(self, user_hash: str) -> List[MissionData]:
        """List missions for a user"""
        missions = []
        
        # Check active missions
        for mission in self.active_missions.values():
            if mission.user_hash == user_hash:
                missions.append(mission)
        
        # Load missions from disk
        for mission_dir in self.missions_base_path.iterdir():
            if mission_dir.is_dir() and mission_dir.name.startswith("mission_"):
                mission_id = mission_dir.name
                if mission_id not in self.active_missions:
                    mission = await self._load_mission_from_disk(mission_id)
                    if mission and mission.user_hash == user_hash:
                        missions.append(mission)
        
        return missions
    
    async def save_mission_message(self, mission_id: str, dashboard_msg_id: str, content: str, 
                                 target_agents: List[str], user_hash: str) -> List[dict]:
        """Save mission message and create individual agent messages"""
        mission_path = self.missions_base_path / mission_id
        messages_dir = mission_path / "messages"
        messages_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().isoformat()
        agent_messages = []
        
        # Create individual agent message files
        for agent in target_agents:
            individual_msg_id = f"{dashboard_msg_id}_{agent}"
            
            # Create individual message file with enhanced agent routing
            message_data = {
                "individual_msg_id": individual_msg_id,
                "dashboard_msg_id": dashboard_msg_id,
                "agent_name": agent,
                "content": content,
                "mission_id": mission_id,
                "user_hash": user_hash,
                "timestamp": timestamp,
                "status": "pending",
                
                # NEW: Agent routing information (NON-BREAKING ADDITION)
                "agent_routing": {
                    "target_agent": agent,
                    "agent_selection_method": "user_selected",
                    "pubsub_target": agent,
                    "requires_agent_online": True,
                    "routing_priority": "normal"
                },
                
                # NEW: Processing instructions (NON-BREAKING ADDITION)
                "processing_instructions": {
                    "requires_context": True,
                    "priority": "normal",
                    "mission_context_required": True,
                    "estimated_processing_time": "2-5 minutes"
                },
                
                # NEW: Bridge routing metadata (NON-BREAKING ADDITION)
                "bridge_routing": {
                    "pubsub_message_format": "MISSION_AGENT_MESSAGE",
                    "pubsub_channel": "agent_messages",
                    "target_agent_name": agent,
                    "hexaeight_lock_required": True,
                    "response_expected": True,
                    "git_commit_before_send": True,
                    "created_by_bridge": "centralized_bridge_v1"
                },
                
                # NEW: Message metadata (NON-BREAKING ADDITION)
                "message_metadata": {
                    "message_type": "user_to_agent",
                    "created_at": timestamp,
                    "created_by_bridge": "bridge_main",
                    "git_path": f"missions/{mission_id}/messages/{individual_msg_id}.json",
                    "version": "1.0"
                }
            }
            
            message_file = messages_dir / f"{individual_msg_id}.json"
            with open(message_file, 'w') as f:
                json.dump(message_data, f, indent=2)
            
            agent_messages.append({
                "agentName": agent,          # camelCase for dashboard
                "messageId": individual_msg_id
            })
        
        # Create overall message status file
        status_file = messages_dir / f"{dashboard_msg_id}_status.json"
        status_data = {
            "dashboard_msg_id": dashboard_msg_id,
            "mission_id": mission_id,
            "content": content,
            "target_agents": target_agents,
            "user_hash": user_hash,
            "timestamp": timestamp,
            "status": "sent",
            "agent_messages": agent_messages
        }
        
        with open(status_file, 'w') as f:
            json.dump(status_data, f, indent=2)
        
        # Commit message files to git if available
        if self.git_tool:
            try:
                # Initialize git repository if needed
                if not hasattr(self, 'git_initialized'):
                    await self._initialize_git_repository()
                
                git_files = []
                
                # Add individual agent message files
                for agent in target_agents:
                    individual_msg_id = f"{dashboard_msg_id}_{agent}"
                    message_data = {
                        "individual_msg_id": individual_msg_id,
                        "dashboard_msg_id": dashboard_msg_id,
                        "agent_name": agent,
                        "content": content,
                        "mission_id": mission_id,
                        "user_hash": user_hash,
                        "timestamp": timestamp,
                        "status": "pending"
                    }
                    
                    git_files.append(GitFileOperation(
                        path=f"missions/{mission_id}/messages/{individual_msg_id}.json",
                        content=json.dumps(message_data, indent=2),
                        operation="add"
                    ))
                
                # Add status file
                git_files.append(GitFileOperation(
                    path=f"missions/{mission_id}/messages/{dashboard_msg_id}_status.json",
                    content=json.dumps(status_data, indent=2),
                    operation="add"
                ))
                
                commit_result = await self.git_tool.commit_files(
                    git_files, 
                    f"[BRIDGE] Message saved for mission {mission_id}: {dashboard_msg_id}"
                )
                
                if commit_result.success:
                    BridgeLogger.log_system(f"✅ Messages committed to git: {commit_result.commit_sha}")
                else:
                    BridgeLogger.log_system(f"⚠️ Git commit failed: {commit_result.message}")
                    
            except Exception as e:
                BridgeLogger.log_system(f"⚠️ Git message commit failed: {e}")
        
        return agent_messages
    
    async def get_mission_messages(self, mission_id: str) -> List[Dict[str, Any]]:
        """Get messages for a mission in dashboard format"""
        mission_path = self.missions_base_path / mission_id
        messages_dir = mission_path / "messages"
        responses_dir = mission_path / "responses"
        
        if not messages_dir.exists():
            return []
        
        # Group messages by dashboard_msg_id
        message_groups = {}
        
        # Load dashboard message status files
        for status_file in messages_dir.glob("*_status.json"):
            try:
                with open(status_file, 'r') as f:
                    status_data = json.load(f)
                
                dashboard_msg_id = status_data.get('dashboard_msg_id')
                if not dashboard_msg_id:
                    continue
                
                message_groups[dashboard_msg_id] = {
                    'id': dashboard_msg_id,
                    'role': 'user',
                    'content': status_data.get('content', ''),
                    'timestamp': status_data.get('timestamp', ''),
                    'targetAgents': status_data.get('target_agents', []),
                    'agentResponses': [],
                    'missionId': mission_id,
                    'status': status_data.get('status', 'pending')
                }
            except Exception as e:
                BridgeLogger.log_system(f"⚠️ Error loading status {status_file}: {e}", "MISSION", "WARNING")
        
        # Load agent responses
        if responses_dir.exists():
            for resp_file in responses_dir.glob("*.json"):
                try:
                    with open(resp_file, 'r') as f:
                        resp_data = json.load(f)
                    
                    dashboard_msg_id = resp_data.get('dashboard_msg_id')
                    if dashboard_msg_id in message_groups:
                        # Convert to Git response format expected by frontend
                        git_response = {
                            'responseId': resp_data.get('response_id', ''),
                            'originalMessageId': resp_data.get('original_message_id', ''),
                            'dashboardMsgId': resp_data.get('dashboard_msg_id', ''),
                            'missionId': resp_data.get('mission_id', ''),
                            'agentName': resp_data.get('agent_name', ''),
                            'responseType': resp_data.get('response_type', ''),
                            'content': resp_data.get('content', ''),
                            'success': resp_data.get('success', True),
                            'errorMessage': resp_data.get('error_message', ''),
                            'processingTimeMs': resp_data.get('processing_time_ms', 0),
                            'createdAt': resp_data.get('created_at', ''),
                            'agentMetadata': resp_data.get('agent_metadata', {}),
                            'source': 'local_cache',
                            'filePath': str(resp_file)
                        }
                        message_groups[dashboard_msg_id]['agentResponses'].append(git_response)
                except Exception as e:
                    BridgeLogger.log_system(f"⚠️ Error loading response {resp_file}: {e}", "MISSION", "WARNING")
        
        # Convert to list and sort by timestamp
        messages = list(message_groups.values())
        messages.sort(key=lambda x: x.get('timestamp', ''))
        
        return messages
    
    async def _load_mission_from_disk(self, mission_id: str) -> Optional[MissionData]:
        """Load mission from disk"""
        try:
            mission_path = self.missions_base_path / mission_id
            context_file = mission_path / "context.json"
            
            if not context_file.exists():
                return None
            
            with open(context_file, 'r') as f:
                context = json.load(f)
            
            mission_data = MissionData(
                id=mission_id,
                title=context.get('title', ''),
                description=context.get('description', ''),
                status=context.get('status', 'unknown'),
                created_at=context.get('created_at', ''),
                last_activity=context.get('last_activity', ''),
                assigned_agents=list(context.get('assigned_agents', {}).keys()),
                user_hash=context.get('user_hash', ''),
                context=context
            )
            
            self.active_missions[mission_id] = mission_data
            return mission_data
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Mission loading error: {e}", "MAIN", "ERROR")
            return None

    async def update_mission_status(self, mission_id: str, new_status: str) -> bool:
        """Update mission status in context.json and active_missions cache"""
        try:
            mission_path = self.missions_base_path / mission_id
            context_file = mission_path / "context.json"
            
            if not context_file.exists():
                BridgeLogger.log_system(f"❌ Mission context not found: {mission_id}", "MISSION", "ERROR")
                return False
            
            # Load current context
            with open(context_file, 'r') as f:
                context_data = json.load(f)
            
            # Update status and last_activity
            old_status = context_data.get('status', 'unknown')
            context_data['status'] = new_status
            context_data['last_activity'] = datetime.now().isoformat()
            
            # Write updated context back
            with open(context_file, 'w') as f:
                json.dump(context_data, f, indent=2)
            
            # Update active_missions cache
            if mission_id in self.active_missions:
                self.active_missions[mission_id].status = new_status
                self.active_missions[mission_id].last_activity = context_data['last_activity']
                
                # For context, also update the context dict
                self.active_missions[mission_id].context['status'] = new_status
                self.active_missions[mission_id].context['last_activity'] = context_data['last_activity']
            
            # Commit to git if available
            if self.git_tool:
                try:
                    if not hasattr(self, 'git_initialized'):
                        await self._initialize_git_repository()
                    
                    git_files = [
                        GitFileOperation(
                            path=f"missions/{mission_id}/context.json",
                            content=json.dumps(context_data, indent=2),
                            operation="add"
                        )
                    ]
                    
                    commit_result = await self.git_tool.commit_files(
                        git_files,
                        commit_message=f"[BRIDGE] Mission status updated: {old_status} → {new_status}"
                    )
                    
                    if commit_result.success:
                        BridgeLogger.log_system(f"✅ Status update committed to git: {commit_result.commit_sha}", "MISSION")
                    else:
                        BridgeLogger.log_system(f"⚠️ Git commit failed: {commit_result.message}", "MISSION", "WARNING")
                        
                except Exception as e:
                    BridgeLogger.log_system(f"⚠️ Git operation failed: {e}", "MISSION", "WARNING")
            
            BridgeLogger.log_system(f"✅ Mission status updated: {mission_id} ({old_status} → {new_status})", "MISSION")
            return True
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Mission status update failed: {e}", "MISSION", "ERROR")
            return False

# =====================================================================================
# PRESERVED: Bridge class with ORIGINAL working initialization
# =====================================================================================

class MissionEnhancedCentralizedBridge:
    """PRESERVED: Original bridge + Mission enhancements"""
    
    def __init__(self, bridge_id: str, port: int = 8080):
        self.bridge_id = bridge_id
        self.port = port
        self.hexaeight_agent: Optional[HexaEightLLMAgent] = None
        
        # PRESERVED: Original user management
        self.active_users: Dict[str, UserContext] = {}  # email_hash -> UserContext
        self.message_queue: Dict[str, BridgeMessage] = {}  # msg_id -> BridgeMessage
        self.processed_messages: Set[str] = set()  # Prevent duplicate processing
        
        # NEW: Git sync rate limiting (5-second cooldown)
        self.sync_timestamps: Dict[str, float] = {}  # response_path -> last_sync_timestamp
        self.sync_cooldown_seconds = 5.0
        
        # PRESERVED: Original stats
        self.message_count = 0
        self.start_time = datetime.now()
        self.message_stats = {
            'published': 0,
            'broker_failures': 0,
            'responses_received': 0,
            'missions_created': 0,
            'mission_messages_sent': 0,
            'last_reset': datetime.now()
        }
        
        # NEW: Mission components (will be initialized after hexaeight_agent)
        self.missions_base_path = Path("./missions")
        self.missions_base_path.mkdir(exist_ok=True)
        self.mission_manager = None  # Will be initialized in start() after hexaeight_agent
        self.proposal_manager = ContextProposalManager(self.missions_base_path)
        
        # NEW: SSE connections (mission-specific)
        self.sse_connections: Dict[str, web.StreamResponse] = {}  # {user_hash}_{mission_id} -> response
        
        # PRESERVED: Original HTTP components
        self.app: Optional[web.Application] = None
        self.runner: Optional[web.AppRunner] = None
        self.site: Optional[web.TCPSite] = None
        
        BridgeLogger.log_system(f"🚀 Mission-enhanced bridge initialized", self.bridge_id)
        
    def _hash_email(self, email: str) -> str:
        """Hash email for privacy"""
        return hashlib.sha256(email.encode()).hexdigest()[:16]

    # =====================================================================================
    # PRESERVED: Original agent initialization with EXACT working patterns
    # =====================================================================================
    
    async def initialize_hexaeight_agent(self):
        """PRESERVED: Original agent initialization (EXACT working version)"""
        try:
            required_vars = [
                "HEXAEIGHT_CLIENT_ID",
                "HEXAEIGHT_TOKENSERVER_URL", 
                "HEXAEIGHT_PUBSUB_URL",
                "HEXAEIGHT_CHILD_CONFIG_FILENAME",
                "HEXAEIGHT_CHILD_CONFIG_PASSSWORD"
            ]
            
            missing_vars = [var for var in required_vars if not os.getenv(var)]
            if missing_vars:
                raise Exception(f"Missing environment variables: {missing_vars}")
            
            config_file = os.getenv("HEXAEIGHT_CHILD_CONFIG_FILENAME")
            password = os.getenv("HEXAEIGHT_CHILD_CONFIG_PASSSWORD")  # Note: Double S in original
            client_id = os.getenv("HEXAEIGHT_CLIENT_ID")
            token_server_url = os.getenv("HEXAEIGHT_TOKENSERVER_URL")
            
            BridgeLogger.log_system(f"🔧 Initializing HexaEight agent...", self.bridge_id)
            BridgeLogger.log_system(f"   Config file: {config_file}", self.bridge_id)
            
            init_task = asyncio.create_task(quick_autogen_llm(
                config_file=config_file,
                agent_type="childLLM",
                password=password,
                client_id=client_id,
                token_server_url=token_server_url
            ))
            
            self.hexaeight_agent = await asyncio.wait_for(init_task, timeout=60.0)
            
            if not self.hexaeight_agent:
                raise Exception("Failed to initialize HexaEight agent")
            
            # Initialize Git tool for the bridge (same as mission_manager)
            try:
                self.git_tool = GitMCPTool(self.hexaeight_agent)
                git_init_success = await self.git_tool.initialize()
                if git_init_success:
                    # Ensure repository is set for the bridge's git tool
                    repo_name = "hexaeight-missions"
                    create_result = await self.git_tool.create_repository(repo_name, initial_commit=False)
                    BridgeLogger.log_system("✅ Bridge Git MCP tool initialized", self.bridge_id)
                else:
                    BridgeLogger.log_system("❌ Bridge Git MCP tool initialization failed", self.bridge_id, "ERROR")
                    self.git_tool = None
            except Exception as e:
                BridgeLogger.log_system(f"⚠️ Bridge Git MCP tool initialization failed: {e}", self.bridge_id, "WARNING")
                self.git_tool = None
            
            # PRESERVED: Original verification logic
            await self._verify_agent_connection()
            
            # Initialize MissionManager now that hexaeight_agent is ready
            self.mission_manager = MissionManager(self.missions_base_path, self.hexaeight_agent)
            BridgeLogger.log_system("✅ MissionManager initialized with proper Git tool", self.bridge_id)
            
            BridgeLogger.log_system("✅ HexaEight agent initialized successfully", self.bridge_id)
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ HexaEight agent initialization failed: {e}", self.bridge_id, "ERROR")
            raise
    
    async def _verify_agent_connection(self):
        """PRESERVED: Original verification (EXACT working version)"""
        verification_attempts = 3
        
        for attempt in range(verification_attempts):
            try:
                BridgeLogger.log_system(f"🔍 Verification attempt {attempt + 1}/{verification_attempts}...", self.bridge_id)
                
                # PRESERVED: Original verification steps
                if not self.hexaeight_agent:
                    raise Exception("HexaEight agent not initialized")
                
                # Test basic functionality
                try:
                    inner_agent = self.hexaeight_agent.hexaeight_agent
                    is_connected = inner_agent.is_connected_to_pubsub()
                    BridgeLogger.log_system(f"Connection test: {'✅ Connected' if is_connected else '❌ Not connected'}", self.bridge_id)
                    if not is_connected:
                        raise Exception("Agent not connected to PubSub")
                except Exception as e:
                    raise Exception(f"PubSub connection check failed: {e}")
                
                BridgeLogger.log_system("✅ Agent verification passed", self.bridge_id)
                return
                
            except Exception as e:
                if attempt < verification_attempts - 1:
                    wait_time = 2.0 * (attempt + 1)
                    BridgeLogger.log_system(f"⚠️ Verification attempt {attempt + 1} failed: {e}", self.bridge_id, "WARNING")
                    BridgeLogger.log_system(f"🔄 Retrying verification in {wait_time}s...", self.bridge_id)
                    await asyncio.sleep(wait_time)
                else:
                    raise Exception(f"Agent verification failed after {verification_attempts} attempts: {e}")
    
    # PRESERVED: Original message listener with ENHANCED mission handling
    async def _setup_message_listener(self):
        """PRESERVED: Setup message listener with ADDED mission handling"""
        if not self.hexaeight_agent or not hasattr(self.hexaeight_agent, 'hexaeight_agent'):
            raise Exception("HexaEight agent not properly initialized")
        
        inner_agent = self.hexaeight_agent.hexaeight_agent
        
        async def message_handler(event):
            """ENHANCED: Handle incoming messages with mission support"""
            try:
                self.message_stats['responses_received'] += 1
                
                content = getattr(event, 'decrypted_content', None)
                if not content:
                    return
                
                sender = getattr(event, 'sender', 'unknown')
                message_id = getattr(event, 'message_id', f"msg_{uuid.uuid4().hex[:8]}")
                
                # NEW: Git-based response notifications
                if self._is_json_message(content):
                    try:
                        json_msg = json.loads(content)
                        if json_msg.get("message_type") == "MISSION_AGENT_RESPONSE":
                            await self._handle_git_agent_response(json_msg, sender)
                            return
                    except json.JSONDecodeError:
                        pass  # Fall through to legacy handling
                
                # NEW: Mission completion notifications (legacy)
                if "MESSAGE_PROCESSING_COMPLETE:" in content:
                    await self._handle_mission_message_completion(content, sender)
                    return
                
                # NEW: Context proposal notifications
                if "CONTEXT_PROPOSAL_CREATED:" in content:
                    await self._handle_context_proposal_creation(content, sender)
                    return
                
                # PRESERVED: Original chat message handling (UNCHANGED)
                if "FROM_COPILOT:" in content:
                    await self._handle_legacy_chat_message(content, sender)
                    return
                
                # Handle other message types
                BridgeLogger.log_system(f"📨 Received message from {sender}: {content[:100]}...", self.bridge_id)
                
            except Exception as e:
                BridgeLogger.log_system(f"❌ Message handler error: {e}", self.bridge_id, "ERROR")
        
        # PRESERVED: Original event handler registration
        inner_agent.register_event_handler('message_received', message_handler)
        await inner_agent.start_event_processing()
        
        BridgeLogger.log_system("✅ Message listener setup", self.bridge_id)
    
    # =====================================================================================
    # NEW: Mission message handlers
    # =====================================================================================
    
    async def _handle_mission_message_completion(self, content: str, sender: str):
        """NEW: Handle mission message completion notification"""
        try:
            # Parse completion notification
            lines = content.split('\n')
            header = lines[0]  # MESSAGE_PROCESSING_COMPLETE:message_id
            
            message_id = header.split(':', 1)[1] if ':' in header else ''
            
            # Extract mission info from content
            mission_id = None
            dashboard_msg_id = None
            
            for line in lines[1:]:
                if line.startswith("MISSION_ID:"):
                    mission_id = line.split(':', 1)[1].strip()
                elif line.startswith("DASHBOARD_MSG_ID:"):
                    dashboard_msg_id = line.split(':', 1)[1].strip()
            
            if mission_id and dashboard_msg_id:
                # Create response file
                await self._create_response_file(mission_id, message_id, dashboard_msg_id, sender, content)
                
                # Send SSE notification to mission
                await self._send_mission_sse(mission_id, {
                    'type': 'agent_response',
                    'dashboardMsgId': dashboard_msg_id,
                    'agentName': sender,
                    'messageId': message_id,
                    'status': 'completed',
                    'timestamp': datetime.now().isoformat()
                })
                
                BridgeLogger.log_system(f"✅ Mission message completion processed: {message_id}", self.bridge_id)
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Mission completion handling error: {e}", self.bridge_id, "ERROR")
    
    async def _handle_context_proposal_creation(self, content: str, sender: str):
        """NEW: Handle context proposal creation from orchestrator"""
        try:
            # Parse proposal content
            lines = content.strip().split('\n')
            
            # Extract proposal data
            proposal_data = {}
            for line in lines[1:]:
                if ':' in line:
                    key, value = line.split(':', 1)
                    proposal_data[key.strip()] = value.strip()
            
            mission_id = proposal_data.get('MISSION_ID')
            message_id = proposal_data.get('MESSAGE_ID')
            
            if mission_id and message_id:
                # Create proposal
                proposal_id = await self.proposal_manager.create_proposal(
                    mission_id=mission_id,
                    message_id=message_id,
                    orchestrator_id=sender,
                    changes={"status": "active"},  # Example change
                    reason="Orchestrator suggested context update"
                )
                
                # Notify dashboard
                await self._send_mission_sse(mission_id, {
                    'type': 'context_proposal_created',
                    'missionId': mission_id,
                    'proposalId': proposal_id,
                    'timestamp': datetime.now().isoformat()
                })
                
                self.message_stats['missions_created'] += 1  # Track proposals
                BridgeLogger.log_system(f"✅ Context proposal created: {proposal_id}", self.bridge_id)
                
        except Exception as e:
            BridgeLogger.log_system(f"❌ Context proposal creation error: {e}", self.bridge_id, "ERROR")
    
    async def _handle_legacy_chat_message(self, content: str, sender: str):
        """PRESERVED: Handle legacy chat message (UNCHANGED functionality)"""
        try:
            BridgeLogger.log_system(f"📨 Legacy chat message from {sender}", self.bridge_id)
            
            # Extract user context
            user_context = self._extract_user_context_from_response(content)
            if user_context:
                # Send via stdout for legacy Node.js bridge compatibility
                response_data = {
                    'type': 'agent_response',
                    'msg_id': user_context.get('msg_id', ''),
                    'content': content,
                    'agent_name': sender,
                    'agent_type': 'HexaEight Agent',
                    'response_type': 'text',
                    'timestamp': datetime.now().isoformat()
                }
                
                print(json.dumps(response_data), flush=True)
                BridgeLogger.log_system("📤 Legacy response sent to stdout", self.bridge_id)
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Legacy chat handling error: {e}", self.bridge_id, "ERROR")
    
    async def _create_response_file(self, mission_id: str, message_id: str, dashboard_msg_id: str, 
                                  agent_name: str, content: str):
        """NEW: Create response file for completed message"""
        try:
            responses_dir = self.missions_base_path / mission_id / "responses"
            responses_dir.mkdir(exist_ok=True)
            
            response_data = {
                "message_id": message_id,
                "dashboard_msg_id": dashboard_msg_id,
                "agent_name": agent_name,
                "content": f"Agent {agent_name} completed processing message {message_id}",
                "timestamp": datetime.now().isoformat(),
                "status": "completed"
            }
            
            response_file = responses_dir / f"{message_id}_response.json"
            with open(response_file, 'w') as f:
                json.dump(response_data, f, indent=2)
            
            BridgeLogger.log_system(f"✅ Response file created: {message_id}", self.bridge_id)
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Response file creation error: {e}", self.bridge_id, "ERROR")
    
    async def _send_individual_message_to_agent(self, agent_name: str, message_id: str, mission_id: str, dashboard_msg_id: str, content: str):
        """Send Git-based message notification with response file monitoring and retry"""
        try:
            # Step 1: Ensure message is committed to Git first
            # The message should already be saved by mission_manager.save_mission_message()
            git_message_path = f"missions/{mission_id}/messages/{message_id}.json"
            expected_response_path = f"missions/{mission_id}/responses/{message_id}_response.json"
            
            # Step 2: Create lightweight JSON notification (NO CONTENT)
            git_notification = {
                "message_type": "MISSION_AGENT_MESSAGE",
                "message_id": message_id,
                "mission_id": mission_id,
                "dashboard_msg_id": dashboard_msg_id,
                "target_agent": agent_name,
                "git_message_path": git_message_path,
                "timestamp": datetime.now().isoformat(),
                "instructions": {
                    "action": "fetch_and_process",
                    "git_repository": f"missions/{mission_id}",
                    "context_required": True,
                    "response_path": expected_response_path
                }
            }
            
            # Step 3: Send PubSub + Monitor Response File with Retry
            if self.hexaeight_agent and hasattr(self.hexaeight_agent, 'hexaeight_agent'):
                inner_agent = self.hexaeight_agent.hexaeight_agent
                pubsub_url = os.getenv("HEXAEIGHT_PUBSUB_URL")
                
                if pubsub_url:
                    success = await self._send_pubsub_with_response_monitoring(
                        inner_agent, pubsub_url, agent_name, git_notification, message_id, expected_response_path
                    )
                    
                    if success:
                        BridgeLogger.log_system(f"✅ Agent {agent_name} processed message {message_id} (response file confirmed)", self.bridge_id)
                        BridgeLogger.log_git_operation("message_processed", True, f"Agent: {agent_name}, Response: {expected_response_path}")
                    else:
                        BridgeLogger.log_system(f"❌ Agent {agent_name} failed to process message {message_id} (no response file after retries)", self.bridge_id, "ERROR")
                        BridgeLogger.log_git_operation("message_processed", False, f"No response from {agent_name} after retries")
                else:
                    BridgeLogger.log_system(f"❌ HEXAEIGHT_PUBSUB_URL not set", self.bridge_id, "ERROR")
            else:
                BridgeLogger.log_system(f"❌ HexaEight agent not available for: {message_id}", self.bridge_id, "ERROR")
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Individual message send error: {e}", self.bridge_id, "ERROR")
    
    def _is_json_message(self, content: str) -> bool:
        """Check if content is a JSON message"""
        try:
            content = content.strip()
            return content.startswith('{') and content.endswith('}')
        except:
            return False
    
    async def _handle_git_agent_response(self, json_msg: dict, sender: str):
        """NEW: Handle Git-based agent response notification with Git sync"""
        try:
            message_id = json_msg.get("original_message_id")
            mission_id = json_msg.get("mission_id")
            dashboard_msg_id = json_msg.get("dashboard_msg_id")
            response_path = json_msg.get("response_path")
            response_type = json_msg.get("response_type", "completed")
            status = json_msg.get("status", "completed")
            
            if not all([message_id, mission_id, dashboard_msg_id, response_path]):
                BridgeLogger.log_system(f"❌ Invalid Git response notification from {sender}", self.bridge_id, "ERROR")
                return
            
            BridgeLogger.log_system(f"✅ Git response received from {sender}: {message_id} (type: {response_type})", self.bridge_id)
            BridgeLogger.log_git_operation("response_received", True, f"Agent: {sender}, Path: {response_path}")
            
            # CRITICAL FIX: Sync response file from Git to local filesystem
            sync_success = await self._sync_response_from_git_to_local(mission_id, response_path, sender)
            
            if sync_success:
                BridgeLogger.log_system(f"✅ Response synced to local filesystem: {response_path}", self.bridge_id)
            else:
                BridgeLogger.log_system(f"⚠️ Failed to sync response to local filesystem: {response_path}", self.bridge_id, "WARNING")
            
            # Send SSE notification to frontend to refresh
            await self._send_mission_sse(mission_id, {
                'type': 'agent_response',
                'dashboardMsgId': dashboard_msg_id,
                'agentName': sender,
                'messageId': message_id,
                'status': status,
                'responseType': response_type,
                'timestamp': datetime.now().isoformat(),
                'gitPath': response_path,
                'refreshRequired': True,  # Tell frontend to fetch from local cache
                'syncSuccess': sync_success
            })
            
            BridgeLogger.log_mission_event("message_responded", mission_id, f"Agent: {sender}, Type: {response_type}")
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Git response handling error: {e}", self.bridge_id, "ERROR")

    async def _sync_response_from_git_to_local(self, mission_id: str, response_path: str, agent_name: str) -> bool:
        """Sync response file from Git to local filesystem with 5-second rate limiting"""
        try:
            # Rate limiting disabled temporarily
            current_time = time.time()
            # last_sync_time = self.sync_timestamps.get(response_path, 0)
            # time_since_last_sync = current_time - last_sync_time
            
            # if time_since_last_sync < self.sync_cooldown_seconds:
            #     remaining_cooldown = self.sync_cooldown_seconds - time_since_last_sync
            #     BridgeLogger.log_system(f"⏸️ Sync rate limited: {response_path} (cooldown: {remaining_cooldown:.1f}s)", self.bridge_id)
            #     return True  # Return True to avoid error - we just skip the sync
            
            BridgeLogger.log_system(f"🔄 Syncing response from Git: {response_path}", self.bridge_id)
            
            # Check if we have git tool available
            if not self.git_tool:
                BridgeLogger.log_system(f"❌ Git tool not available for sync", self.bridge_id, "ERROR")
                return False
            
            # Read response content from Git
            read_result = await self.git_tool.read_file(response_path)
            
            if not read_result.get("success"):
                error_msg = read_result.get("error", "Unknown error")
                BridgeLogger.log_system(f"❌ Failed to read response from Git: {response_path} - {error_msg}", self.bridge_id, "ERROR")
                return False
            
            response_content = read_result.get("content", "")
            if not response_content:
                BridgeLogger.log_system(f"❌ Empty response content from Git: {response_path}", self.bridge_id, "ERROR")
                return False
            
            # Parse response path to get local file path
            # response_path format: "missions/{mission_id}/responses/{message_id}_response.json"
            path_parts = response_path.split('/')
            if len(path_parts) >= 4 and path_parts[0] == "missions" and path_parts[2] == "responses":
                mission_id_from_path = path_parts[1]
                response_filename = path_parts[3]  # e.g., "msg-xxx_response.json"
                
                # Create local responses directory
                local_responses_dir = self.missions_base_path / mission_id_from_path / "responses"
                local_responses_dir.mkdir(parents=True, exist_ok=True)
                
                # Write response file to local filesystem
                local_response_file = local_responses_dir / response_filename
                with open(local_response_file, 'w', encoding='utf-8') as f:
                    f.write(response_content)
                
                # Update sync timestamp for rate limiting
                self.sync_timestamps[response_path] = current_time
                
                BridgeLogger.log_system(f"✅ Response synced to local: {local_response_file}", self.bridge_id)
                return True
            else:
                BridgeLogger.log_system(f"❌ Invalid response path format: {response_path}", self.bridge_id, "ERROR")
                return False
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Error syncing response from Git: {e}", self.bridge_id, "ERROR")
            return False

    def _cleanup_old_sync_timestamps(self):
        """Clean up sync timestamps older than 1 hour to prevent memory leaks"""
        try:
            current_time = time.time()
            one_hour_ago = current_time - 3600  # 1 hour in seconds
            
            # Remove timestamps older than 1 hour
            old_keys = [path for path, timestamp in self.sync_timestamps.items() if timestamp < one_hour_ago]
            for old_key in old_keys:
                del self.sync_timestamps[old_key]
            
            if old_keys:
                BridgeLogger.log_system(f"🗑️ Cleaned up {len(old_keys)} old sync timestamps", self.bridge_id)
                
        except Exception as e:
            BridgeLogger.log_system(f"❌ Error cleaning sync timestamps: {e}", self.bridge_id, "ERROR")

    async def _periodic_cleanup_task(self):
        """Periodic cleanup task to prevent memory leaks"""
        try:
            while True:
                await asyncio.sleep(300)  # Run every 5 minutes
                self._cleanup_old_sync_timestamps()
                
        except asyncio.CancelledError:
            BridgeLogger.log_system("🛑 Periodic cleanup task cancelled", self.bridge_id)
        except Exception as e:
            BridgeLogger.log_system(f"❌ Periodic cleanup task error: {e}", self.bridge_id, "ERROR")
    
    async def _send_mission_sse(self, mission_id: str, data: Dict[str, Any]):
        """NEW: Send SSE message to all connections for a mission"""
        try:
            # Find all connections for this mission
            connections_to_send = []
            for connection_key, response in self.sse_connections.items():
                if connection_key.endswith(f"_{mission_id}"):
                    connections_to_send.append(response)
            
            if not connections_to_send:
                return
            
            # Format SSE message
            sse_data = f"data: {json.dumps(data)}\n\n"
            
            # Send to all connections
            for response in connections_to_send:
                try:
                    await response.write(sse_data.encode())
                    await response.drain()
                except Exception as e:
                    BridgeLogger.log_system(f"⚠️ SSE send failed: {e}", self.bridge_id, "WARNING")
            
            BridgeLogger.log_system(f"📡 SSE sent to {len(connections_to_send)} connections", self.bridge_id)
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ SSE broadcast error: {e}", self.bridge_id, "ERROR")
    
    def _extract_user_context_from_response(self, content: str) -> Optional[dict]:
        """PRESERVED: Extract user context from legacy response (UNCHANGED)"""
        try:
            if "FROM_COPILOT:" in content:
                lines = content.split('\n')
                header = lines[0]
                parts = header.split(':')
                if len(parts) >= 3:
                    return {
                        'user_id': parts[1],
                        'msg_id': parts[2]
                    }
            return None
        except Exception:
            return None

    # =====================================================================================
    # PRESERVED: Original HTTP server setup with ADDED mission endpoints
    # =====================================================================================
    
    async def setup_http_server(self):
        """PRESERVED: Original server setup + NEW mission endpoints"""
        
        self.app = web.Application()
        
        # CORS setup
        cors = aiohttp_cors.setup(self.app, defaults={
            "*": aiohttp_cors.ResourceOptions(
                allow_credentials=True,
                expose_headers="*",
                allow_headers="*",
                allow_methods="*"
            )
        })
        
        # NEW: Mission endpoints for dashboard
        self.app.router.add_post('/api/missions/create', self._handle_create_mission)
        self.app.router.add_get('/api/missions/list', self._handle_list_missions)
        self.app.router.add_get('/api/missions/archived', self._handle_list_archived_missions)
        self.app.router.add_get('/api/missions/{mission_id}/context', self._handle_get_mission_context)
        self.app.router.add_post('/api/missions/{mission_id}/message', self._handle_mission_message)
        self.app.router.add_get('/api/missions/{mission_id}/messages', self._handle_get_mission_messages)
        self.app.router.add_get('/api/missions/{mission_id}/sse', self._handle_mission_sse)
        self.app.router.add_delete('/api/missions/{mission_id}', self._handle_delete_mission)
        self.app.router.add_patch('/api/missions/{mission_id}', self._handle_update_mission)
        
        # NEW: Git-based agent response endpoints
        self.app.router.add_get('/api/missions/{mission_id}/responses', self._handle_get_agent_responses)
        self.app.router.add_get('/api/missions/{mission_id}/responses/{message_id}', self._handle_get_message_responses)
        self.app.router.add_get('/api/missions/{mission_id}/agent/{agent_name}/responses', self._handle_get_agent_specific_responses)
        self.app.router.add_post('/api/missions/{mission_id}/responses/sync', self._handle_sync_responses_from_git)
        
        # NEW: Context proposal endpoints
        self.app.router.add_get('/api/missions/{mission_id}/proposals', self._handle_get_proposals)
        self.app.router.add_post('/api/missions/{mission_id}/proposals/{proposal_id}/approve', self._handle_approve_proposal)
        
        # NEW: Agent management endpoints
        self.app.router.add_post('/api/bridge/agents/add', self._handle_add_agent)
        self.app.router.add_delete('/api/bridge/agents/remove', self._handle_remove_agent)
        self.app.router.add_get('/api/bridge/agents/user', self._handle_get_user_agents)
        
        # NEW: Mission-Agent assignment endpoints
        self.app.router.add_put('/api/missions/{mission_id}/agents/{agent_name}', self._handle_assign_agent_to_mission)
        self.app.router.add_delete('/api/missions/{mission_id}/agents/{agent_name}', self._handle_remove_agent_from_mission)
        
        # PRESERVED: Original endpoints (for backward compatibility)
        self.app.router.add_post('/api/chat/send', self._handle_send_message)
        self.app.router.add_get('/api/chat/sse', self._handle_legacy_sse)
        self.app.router.add_get('/api/status', self._handle_status)
        self.app.router.add_get('/health', self._handle_health)
        self.app.router.add_get('/api/stats', self._handle_stats)
        self.app.router.add_post('/api/stats/reset', self._handle_reset_stats)
        self.app.router.add_get('/api/git/status', self._handle_git_status)
        self.app.router.add_get('/api/monitoring/metrics', self._handle_monitoring_metrics)
        self.app.router.add_get('/api/monitoring/health', self._handle_monitoring_health)
        
        # Add CORS to all routes
        for route in list(self.app.router.routes()):
            cors.add(route)
        
        # Start server
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        
        self.site = web.TCPSite(self.runner, 'localhost', self.port)
        await self.site.start()
        
        BridgeLogger.log_system(f"🌐 Enhanced HTTP server running on http://localhost:{self.port}", self.bridge_id)
        BridgeLogger.log_system(f"   📊 Dashboard endpoint: http://localhost:{self.port}/api/missions/list", self.bridge_id)

    # =====================================================================================
    # NEW: Mission API handlers
    # =====================================================================================
    
    async def _handle_create_mission(self, request):
        """NEW: Handle mission creation"""
        try:
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("POST", "/api/missions/create", user_email)
            
            data = await request.json()
            
            title = data.get('title', '')
            description = data.get('description', '')
            agent_ids = data.get('agent_ids', [])
            
            if not title or not description:
                return web.json_response({
                    'success': False,
                    'error': 'Title and description are required'
                }, status=400)
            
            # Create mission
            mission = await self.mission_manager.create_mission(title, description, agent_ids, user_hash)
            self.message_stats['missions_created'] += 1
            
            # Enhanced logging
            BridgeLogger.log_mission_event("created", mission.id, f"Title: {title}, Agents: {len(agent_ids)}", status=mission.status)
            
            # Return mission data in dashboard format (camelCase)
            response_data = {
                'success': True,
                'mission': {
                    'id': mission.id,
                    'title': mission.title,
                    'description': mission.description,
                    'status': mission.status,
                    'created_at': mission.created_at,
                    'assigned_agents': mission.context.get('assigned_agents', {})
                }
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Mission creation error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_list_missions(self, request):
        """NEW: Handle mission list request"""
        try:
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("GET", "/api/missions/list", user_email)
            
            missions = await self.mission_manager.list_user_missions(user_hash)
            
            mission_list = []
            for mission in missions:
                # Filter out inactive missions (they are "deleted")
                if mission.status != 'inactive':
                    mission_list.append({
                        'id': mission.id,
                        'title': mission.title,
                        'description': mission.description,
                        'status': mission.status,
                        'created_at': mission.created_at,
                        'last_activity': mission.last_activity,
                        'assigned_agents': mission.context.get('assigned_agents', {})
                    })
            
            response_data = {
                'success': True,
                'missions': mission_list
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Mission list error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)

    async def _handle_list_archived_missions(self, request):
        """NEW: Handle archived (inactive) missions list request for restore functionality"""
        try:
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("GET", "/api/missions/archived", user_email)
            
            missions = await self.mission_manager.list_user_missions(user_hash)
            
            mission_list = []
            for mission in missions:
                # Include both inactive (deleted) and archived missions (both are restorable)
                if mission.status in ['inactive', 'archived']:
                    mission_list.append({
                        'id': mission.id,
                        'title': mission.title,
                        'description': mission.description,
                        'status': mission.status,
                        'created_at': mission.created_at,
                        'last_activity': mission.last_activity,
                        'assigned_agents': mission.context.get('assigned_agents', {})
                    })
            
            response_data = {
                'success': True,
                'missions': mission_list
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Archived missions list error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_get_mission_context(self, request):
        """NEW: Handle mission context request"""
        try:
            mission_id = request.match_info['mission_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            
            BridgeLogger.log_http_request("GET", f"/api/missions/{mission_id}/context", user_email)
            
            mission = await self.mission_manager.get_mission(mission_id)
            if not mission:
                return web.json_response({
                    'success': False,
                    'error': 'Mission not found'
                }, status=404)
            
            response_data = {
                'success': True,
                'context': mission.context
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Mission context error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_mission_message(self, request):
        """NEW: Handle mission message sending"""
        try:
            mission_id = request.match_info['mission_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("POST", f"/api/missions/{mission_id}/message", user_email)
            
            data = await request.json()
            
            dashboard_msg_id = data.get('dashboard_msg_id', '')
            content = data.get('content', '')
            target_agents = data.get('target_agents', [])
            
            if not dashboard_msg_id or not content or not target_agents:
                return web.json_response({
                    'success': False,
                    'error': 'dashboard_msg_id, content, and target_agents are required'
                }, status=400)
            
            # Save mission message and create individual agent messages
            agent_messages = await self.mission_manager.save_mission_message(
                mission_id, dashboard_msg_id, content, target_agents, user_hash
            )
            
            # Send individual messages to agents (via orchestrator)
            for agent_msg in agent_messages:
                await self._send_individual_message_to_agent(
                    agent_msg['agentName'],
                    agent_msg['messageId'],
                    mission_id,
                    dashboard_msg_id,
                    content
                )
            
            self.message_stats['mission_messages_sent'] += len(agent_messages)
            
            response_data = {
                'success': True,
                'dashboard_msg_id': dashboard_msg_id,
                'messages': agent_messages
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Mission message error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_get_mission_messages(self, request):
        """NEW: Handle mission messages request"""
        try:
            mission_id = request.match_info['mission_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            
            BridgeLogger.log_http_request("GET", f"/api/missions/{mission_id}/messages", user_email)
            
            messages = await self.mission_manager.get_mission_messages(mission_id)
            
            response_data = {
                'success': True,
                'messages': messages
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Mission messages error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_mission_sse(self, request):
        """NEW: Handle mission-specific SSE connections"""
        try:
            mission_id = request.match_info['mission_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("GET", f"/api/missions/{mission_id}/sse", user_email)
            
            response = web.StreamResponse()
            response.headers['Content-Type'] = 'text/event-stream'
            response.headers['Cache-Control'] = 'no-cache'
            response.headers['Connection'] = 'keep-alive'
            response.headers['Access-Control-Allow-Origin'] = '*'
            
            await response.prepare(request)
            
            # Add connection with mission-specific key
            connection_key = f"{user_hash}_{mission_id}"
            self.sse_connections[connection_key] = response
            
            # Send initial connection message
            initial_message = {
                "type": "connection_established",
                "missionId": mission_id,
                "timestamp": datetime.now().isoformat()
            }
            
            sse_data = f"data: {json.dumps(initial_message)}\n\n"
            await response.write(sse_data.encode())
            await response.drain()
            
            BridgeLogger.log_system(f"📡 SSE connection established: {connection_key}", self.bridge_id)
            
            # Keep connection alive
            try:
                while True:
                    await asyncio.sleep(30)  # Send heartbeat every 30 seconds
                    heartbeat = {
                        "type": "heartbeat",
                        "timestamp": datetime.now().isoformat()
                    }
                    sse_data = f"data: {json.dumps(heartbeat)}\n\n"
                    await response.write(sse_data.encode())
                    await response.drain()
                    
            except asyncio.CancelledError:
                pass
            except Exception as e:
                BridgeLogger.log_system(f"⚠️ SSE connection error for {connection_key}: {e}", self.bridge_id, "WARNING")
            finally:
                if connection_key in self.sse_connections:
                    del self.sse_connections[connection_key]
                    BridgeLogger.log_system(f"📡 SSE connection closed: {connection_key}", self.bridge_id)
            
            return response
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ SSE setup error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)

    async def _handle_delete_mission(self, request):
        """NEW: Handle mission deletion (mark as inactive)"""
        try:
            mission_id = request.match_info['mission_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("DELETE", f"/api/missions/{mission_id}", user_email)
            
            # Get mission and verify ownership
            mission = await self.mission_manager.get_mission(mission_id)
            if not mission or mission.user_hash != user_hash:
                return web.json_response({
                    'success': False,
                    'error': 'Mission not found or access denied'
                }, status=404)
            
            # Mark mission as inactive (don't actually delete)
            success = await self.mission_manager.update_mission_status(mission_id, 'inactive')
            
            if success:
                # Remove from active missions cache
                if mission_id in self.mission_manager.active_missions:
                    del self.mission_manager.active_missions[mission_id]
                
                return web.json_response({
                    'success': True,
                    'message': 'Mission marked as inactive',
                    'mission_id': mission_id
                })
            else:
                return web.json_response({
                    'success': False,
                    'error': 'Failed to update mission status'
                }, status=500)
                
        except Exception as e:
            BridgeLogger.log_system(f"❌ Mission delete error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)

    async def _handle_update_mission(self, request):
        """NEW: Handle mission updates (for restore functionality)"""
        try:
            mission_id = request.match_info['mission_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            data = await request.json()
            
            BridgeLogger.log_http_request("PATCH", f"/api/missions/{mission_id}", user_email)
            
            # Get mission and verify ownership
            mission = await self.mission_manager.get_mission(mission_id)
            if not mission or mission.user_hash != user_hash:
                return web.json_response({
                    'success': False,
                    'error': 'Mission not found or access denied'
                }, status=404)
            
            # Update mission status (typically for restore)
            new_status = data.get('status')
            if new_status and new_status in ['requirements_gathering', 'planning', 'active', 'completed', 'archived', 'inactive']:
                success = await self.mission_manager.update_mission_status(mission_id, new_status)
                
                if success:
                    # Re-add to active missions cache if restoring
                    if new_status != 'inactive':
                        updated_mission = await self.mission_manager.get_mission(mission_id)
                        if updated_mission:
                            self.mission_manager.active_missions[mission_id] = updated_mission
                    
                    return web.json_response({
                        'success': True,
                        'message': f'Mission status updated to {new_status}',
                        'mission_id': mission_id,
                        'new_status': new_status
                    })
                else:
                    return web.json_response({
                        'success': False,
                        'error': 'Failed to update mission status'
                    }, status=500)
            else:
                return web.json_response({
                    'success': False,
                    'error': 'Invalid or missing status field'
                }, status=400)
                
        except Exception as e:
            BridgeLogger.log_system(f"❌ Mission update error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    # =====================================================================================
    # GIT-BASED AGENT RESPONSE HANDLERS
    # =====================================================================================
    
    async def _handle_get_agent_responses(self, request):
        """NEW: Get all agent responses for a mission from Git"""
        try:
            mission_id = request.match_info['mission_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("GET", f"/api/missions/{mission_id}/responses", user_email)
            
            # Verify mission ownership
            mission = await self.mission_manager.get_mission(mission_id)
            if not mission or mission.user_hash != user_hash:
                return web.json_response({
                    'success': False,
                    'error': 'Mission not found or access denied'
                }, status=404)
            
            # Fetch agent responses from Git and local cache
            responses = await self._fetch_agent_responses_for_mission(mission_id)
            
            response_data = {
                'success': True,
                'mission_id': mission_id,
                'responses': responses,
                'total_count': len(responses)
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Get agent responses error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_get_message_responses(self, request):
        """NEW: Get agent responses for a specific message from Git"""
        try:
            mission_id = request.match_info['mission_id']
            message_id = request.match_info['message_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("GET", f"/api/missions/{mission_id}/responses/{message_id}", user_email)
            
            # Verify mission ownership
            mission = await self.mission_manager.get_mission(mission_id)
            if not mission or mission.user_hash != user_hash:
                return web.json_response({
                    'success': False,
                    'error': 'Mission not found or access denied'
                }, status=404)
            
            # Fetch responses for specific message
            responses = await self._fetch_responses_for_message(mission_id, message_id)
            
            response_data = {
                'success': True,
                'mission_id': mission_id,
                'message_id': message_id,
                'responses': responses,
                'response_count': len(responses)
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Get message responses error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_get_agent_specific_responses(self, request):
        """NEW: Get responses from a specific agent in a mission"""
        try:
            mission_id = request.match_info['mission_id']
            agent_name = request.match_info['agent_name']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("GET", f"/api/missions/{mission_id}/agent/{agent_name}/responses", user_email)
            
            # Verify mission ownership
            mission = await self.mission_manager.get_mission(mission_id)
            if not mission or mission.user_hash != user_hash:
                return web.json_response({
                    'success': False,
                    'error': 'Mission not found or access denied'
                }, status=404)
            
            # Fetch responses from specific agent
            responses = await self._fetch_agent_specific_responses(mission_id, agent_name)
            
            response_data = {
                'success': True,
                'mission_id': mission_id,
                'agent_name': agent_name,
                'responses': responses,
                'response_count': len(responses)
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Get agent specific responses error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_sync_responses_from_git(self, request):
        """NEW: Manually sync agent responses from Git repositories"""
        try:
            mission_id = request.match_info['mission_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("POST", f"/api/missions/{mission_id}/responses/sync", user_email)
            
            # Verify mission ownership
            mission = await self.mission_manager.get_mission(mission_id)
            if not mission or mission.user_hash != user_hash:
                return web.json_response({
                    'success': False,
                    'error': 'Mission not found or access denied'
                }, status=404)
            
            # Force sync from Git
            sync_result = await self._sync_mission_responses_from_git(mission_id)
            
            response_data = {
                'success': sync_result['success'],
                'mission_id': mission_id,
                'synced_responses': sync_result.get('synced_count', 0),
                'details': sync_result.get('details', [])
            }
            
            if not sync_result['success']:
                response_data['error'] = sync_result.get('error', 'Sync failed')
                return web.json_response(response_data, status=500)
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Sync responses error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_get_proposals(self, request):
        """NEW: Handle get proposals request"""
        try:
            mission_id = request.match_info['mission_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            
            BridgeLogger.log_http_request("GET", f"/api/missions/{mission_id}/proposals", user_email)
            
            proposals = await self.proposal_manager.get_proposals(mission_id)
            
            response_data = {
                'success': True,
                'proposals': proposals
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Get proposals error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_approve_proposal(self, request):
        """NEW: Handle proposal approval"""
        try:
            mission_id = request.match_info['mission_id']
            proposal_id = request.match_info['proposal_id']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            
            BridgeLogger.log_http_request("POST", f"/api/missions/{mission_id}/proposals/{proposal_id}/approve", user_email)
            
            data = await request.json()
            approved = data.get('approved', False)
            
            success = await self.proposal_manager.process_user_approval(mission_id, proposal_id, approved)
            
            if success:
                if approved:
                    # Notify dashboard of context update
                    await self._send_mission_sse(mission_id, {
                        'type': 'context_updated',
                        'missionId': mission_id,
                        'timestamp': datetime.now().isoformat()
                    })
                
                response_data = {
                    'success': True,
                    'message': 'Proposal processed successfully'
                }
            else:
                response_data = {
                    'success': False,
                    'error': 'Failed to process proposal'
                }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Approve proposal error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    # =====================================================================================
    # NEW: Agent Management API handlers
    # =====================================================================================
    
    async def _handle_add_agent(self, request):
        """NEW: Handle agent creation request"""
        try:
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("POST", "/api/bridge/agents/add", user_email)
            
            data = await request.json()
            name = data.get('name', '')
            description = data.get('description', '')
            
            if not name or not description:
                return web.json_response({
                    'success': False,
                    'error': 'Name and description are required'
                }, status=400)
            
            # Create agent entry in user's agent registry
            agents_file = self.missions_base_path / f"agents_{user_hash}.json"
            
            # Load existing agents
            agents_data = {'agents': []}
            if agents_file.exists():
                try:
                    with open(agents_file, 'r') as f:
                        agents_data = json.load(f)
                except Exception:
                    agents_data = {'agents': []}
            
            # Check if agent already exists
            existing_agent = next((a for a in agents_data['agents'] if a['name'] == name), None)
            if existing_agent:
                return web.json_response({
                    'success': False,
                    'error': f'Agent {name} already exists'
                }, status=409)
            
            # Add new agent
            new_agent = {
                'name': name,
                'description': description,
                'status': 'active',
                'created_at': datetime.now().isoformat(),
                'user_hash': user_hash,
                'capabilities': ['message_processing', 'mission_participation'],
                'type': 'user_created'
            }
            
            agents_data['agents'].append(new_agent)
            
            # Save agents registry
            with open(agents_file, 'w') as f:
                json.dump(agents_data, f, indent=2)
            
            BridgeLogger.log_system(f"✅ Agent created: {name} for user {user_email}", self.bridge_id)
            
            response_data = {
                'success': True,
                'agent': new_agent
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(response_data))
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Add agent error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_remove_agent(self, request):
        """NEW: Handle agent removal request"""
        try:
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("DELETE", "/api/bridge/agents/remove", user_email)
            
            data = await request.json()
            name = data.get('name', '')
            
            if not name:
                return web.json_response({
                    'success': False,
                    'error': 'Agent name is required'
                }, status=400)
            
            # Load agents registry
            agents_file = self.missions_base_path / f"agents_{user_hash}.json"
            
            if not agents_file.exists():
                return web.json_response({
                    'success': False,
                    'error': 'No agents found'
                }, status=404)
            
            with open(agents_file, 'r') as f:
                agents_data = json.load(f)
            
            # Find and remove agent
            original_count = len(agents_data['agents'])
            agents_data['agents'] = [a for a in agents_data['agents'] if a['name'] != name]
            
            if len(agents_data['agents']) == original_count:
                # Agent not found, but don't return 404 - just log it
                BridgeLogger.log_system(f"⚠️ Agent removal attempted for non-existent agent: {name} for user {user_email}", self.bridge_id, "WARNING")
                return web.json_response({
                    'success': True,
                    'message': f'Agent {name} was not found (may have been already removed)',
                    'warning': 'Agent not in user registry'
                })
            
            # Save updated registry
            with open(agents_file, 'w') as f:
                json.dump(agents_data, f, indent=2)
            
            BridgeLogger.log_system(f"✅ Agent removed: {name} for user {user_email}", self.bridge_id)
            
            return web.json_response({
                'success': True,
                'message': f'Agent {name} removed successfully'
            })
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Remove agent error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_get_user_agents(self, request):
        """NEW: Handle get user agents request"""
        try:
            
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("GET", "/api/bridge/agents/user", user_email)
            
            
            # Load agents registry
            agents_file = self.missions_base_path / f"agents_{user_hash}.json"
            
            
            file_exists = agents_file.exists()
            
            agents_list = []
            
            if file_exists:
                try:
                    with open(agents_file, 'r') as f:
                        agents_data = json.load(f)
                    
                    agents_list = agents_data.get('agents', [])
                except Exception as e:
                    BridgeLogger.log_system(f"⚠️ Error loading agents: {e}", self.bridge_id, "WARNING")
            
            # Return agents data in dashboard format (camelCase)
            response_data = {
                'success': True,
                'agents': agents_list,
                'total_agents': len(agents_list)
            }
            
            final_response = CamelCaseConverter.convert_keys_to_camel_case(response_data)
            return web.json_response(final_response)
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Get agents error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e),
                'agents': []
            }, status=500)
    
    async def _handle_assign_agent_to_mission(self, request):
        """NEW: Handle assigning agent to mission"""
        try:
            mission_id = request.match_info['mission_id']
            agent_name = request.match_info['agent_name']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("PUT", f"/api/missions/{mission_id}/agents/{agent_name}", user_email)
            
            # Verify mission exists and user has access
            mission = await self.mission_manager.get_mission(mission_id)
            if not mission or mission.user_hash != user_hash:
                return web.json_response({
                    'success': False,
                    'error': 'Mission not found or access denied'
                }, status=404)
            
            # Verify agent exists for this user
            agents_file = self.missions_base_path / f"agents_{user_hash}.json"
            if not agents_file.exists():
                return web.json_response({
                    'success': False,
                    'error': 'No agents found for user'
                }, status=404)
            
            with open(agents_file, 'r') as f:
                agents_data = json.load(f)
            
            agent_exists = any(agent['name'] == agent_name for agent in agents_data.get('agents', []))
            if not agent_exists:
                return web.json_response({
                    'success': False,
                    'error': 'Agent not found'
                }, status=404)
            
            # Update mission context.json with agent assignment
            mission_path = self.missions_base_path / mission_id
            context_file = mission_path / "context.json"
            
            # Use bridge exclusive context update lock
            async with self.proposal_manager.context_update_lock:
                with open(context_file, 'r') as f:
                    context = json.load(f)
                
                # Add agent to assigned_agents
                if 'assigned_agents' not in context:
                    context['assigned_agents'] = {}
                
                context['assigned_agents'][agent_name] = 'assigned'
                context['last_activity'] = datetime.now().isoformat()
                
                with open(context_file, 'w') as f:
                    json.dump(context, f, indent=2)
                
                # Update in-memory mission data
                if mission_id in self.mission_manager.active_missions:
                    mission_data = self.mission_manager.active_missions[mission_id]
                    # Update the list from context dictionary keys
                    mission_data.assigned_agents = list(context.get('assigned_agents', {}).keys())
                    mission_data.last_activity = datetime.now().isoformat()
                    mission_data.context = context
            
            BridgeLogger.log_system(f"✅ Agent {agent_name} assigned to mission {mission_id}", self.bridge_id, "INFO")
            
            return web.json_response({
                'success': True,
                'message': f'Agent {agent_name} assigned to mission successfully'
            })
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Agent assignment error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_remove_agent_from_mission(self, request):
        """NEW: Handle removing agent from mission"""
        try:
            mission_id = request.match_info['mission_id']
            agent_name = request.match_info['agent_name']
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_hash = self._hash_email(user_email)
            
            BridgeLogger.log_http_request("DELETE", f"/api/missions/{mission_id}/agents/{agent_name}", user_email)
            
            # Verify mission exists and user has access
            mission = await self.mission_manager.get_mission(mission_id)
            if not mission or mission.user_hash != user_hash:
                return web.json_response({
                    'success': False,
                    'error': 'Mission not found or access denied'
                }, status=404)
            
            # Update mission context.json to remove agent assignment
            mission_path = self.missions_base_path / mission_id
            context_file = mission_path / "context.json"
            
            # Use bridge exclusive context update lock
            async with self.proposal_manager.context_update_lock:
                with open(context_file, 'r') as f:
                    context = json.load(f)
                
                # Remove agent from assigned_agents
                if 'assigned_agents' in context and agent_name in context['assigned_agents']:
                    del context['assigned_agents'][agent_name]
                    context['last_activity'] = datetime.now().isoformat()
                    
                    with open(context_file, 'w') as f:
                        json.dump(context, f, indent=2)
                    
                    # Update in-memory mission data
                    if mission_id in self.mission_manager.active_missions:
                        mission_data = self.mission_manager.active_missions[mission_id]
                        # Update the list from context dictionary keys
                        mission_data.assigned_agents = list(context.get('assigned_agents', {}).keys())
                        mission_data.last_activity = datetime.now().isoformat()
                        mission_data.context = context
            
            BridgeLogger.log_system(f"✅ Agent {agent_name} removed from mission {mission_id}", self.bridge_id, "INFO")
            
            return web.json_response({
                'success': True,
                'message': f'Agent {agent_name} removed from mission successfully'
            })
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Agent removal error: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    # =====================================================================================
    # PRESERVED: Original API handlers (for backward compatibility)
    # =====================================================================================
    
    async def _handle_send_message(self, request):
        """PRESERVED: Original send message handler (UNCHANGED)"""
        try:
            data = await request.json()
            
            user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
            user_id = request.headers.get('X-User-ID', 'unknown')
            session_id = request.headers.get('X-Session-ID', f"session-{uuid.uuid4().hex[:8]}")
            
            message_content = data.get('message', '')
            msg_id = f"msg-{int(time.time() * 1000)}-{uuid.uuid4().hex[:8]}"
            
            if not message_content.strip():
                return web.json_response({'error': 'Message content required'}, status=400)
            
            BridgeLogger.log_http_request("POST", "/api/chat/send", user_email)
            BridgeLogger.log_message_flow("IN", user_email, message_content, msg_id)
            
            if msg_id in self.processed_messages:
                return web.json_response({
                    'success': False,
                    'error': 'Duplicate message',
                    'msg_id': msg_id
                })
            
            self.processed_messages.add(msg_id)
            
            email_hash = self._hash_email(user_email)
            user_context = UserContext(
                user_id=user_id,
                user_email=user_email,
                session_id=session_id,
                created_at=datetime.now().isoformat(),
                last_activity=datetime.now().isoformat()
            )
            
            self.active_users[email_hash] = user_context
            
            bridge_msg = BridgeMessage(
                msg_id=msg_id,
                user_context=user_context,
                content=message_content,
                timestamp=datetime.now().isoformat(),
                status='pending',
                bridge_id=self.bridge_id
            )
            
            self.message_queue[msg_id] = bridge_msg
            
            # Route to HexaEight agent
            await self._route_to_hexaeight_agent(bridge_msg)
            
            self.message_count += 1
            
            return web.json_response({
                'success': True,
                'msg_id': msg_id,
                'bridge_id': self.bridge_id,
                'session_id': session_id
            })
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Send message error: {e}", self.bridge_id, "ERROR")
            return web.json_response({'success': False, 'error': str(e)}, status=500)
    
    async def _route_to_hexaeight_agent(self, bridge_msg: BridgeMessage):
        """PRESERVED: Route message to HexaEight agent (UNCHANGED)"""
        try:
            # Determine target agent
            target_agent = self._determine_target_agent(bridge_msg.content)
            formatted_message = self._format_hexaeight_message(bridge_msg)
            
            BridgeLogger.log_message_flow("OUT", bridge_msg.user_context.user_email, formatted_message, bridge_msg.msg_id)
            
            bridge_msg.status = 'sending'
            
            inner_agent = self.hexaeight_agent.hexaeight_agent
            pubsub_url = os.getenv("HEXAEIGHT_PUBSUB_URL", "")
            
            try:
                await inner_agent.publish_to_agent(pubsub_url, target_agent, formatted_message)
                bridge_msg.status = 'sent'
                self.message_stats['published'] += 1
                BridgeLogger.log_system(f"✅ Message published to {target_agent}", self.bridge_id)
                
            except Exception as e:
                bridge_msg.status = 'failed'
                self.message_stats['broker_failures'] += 1
                BridgeLogger.log_system(f"❌ Broker error for {target_agent}: {e}", self.bridge_id, "ERROR")
                
        except Exception as e:
            bridge_msg.status = 'failed'
            self.message_stats['broker_failures'] += 1
            BridgeLogger.log_system(f"❌ Routing error: {e}", self.bridge_id, "ERROR")

    def _determine_target_agent(self, content: str) -> str:
        """PRESERVED: Determine target agent (UNCHANGED)"""
        import re
        mentions = re.findall(r'@([a-zA-Z0-9\-_]+)', content)

        if mentions:
            target_agent = mentions[0]
            BridgeLogger.log_system(f"🎯 Targeting agent from @mention: {target_agent}", self.bridge_id)
            return target_agent

        BridgeLogger.log_system(f"🎯 No @mention found, defaulting to master-agent-generator", self.bridge_id)
        return "master-agent-generator"

    def _format_hexaeight_message(self, bridge_msg: BridgeMessage) -> str:
        """PRESERVED: Format HexaEight message (UNCHANGED)"""
        user_context = bridge_msg.user_context
        
        user_hash = self._hash_email(user_context.user_email)[:8]
        user_id = f"web-{user_hash}-{user_context.session_id[-6:]}"
        
        formatted_message = f"FROM_COPILOT:{user_id}:{bridge_msg.msg_id} {bridge_msg.content}"
        
        return formatted_message
    
    async def _handle_legacy_sse(self, request):
        """PRESERVED: Legacy SSE handler (for backward compatibility)"""
        user_email = request.headers.get('X-User-Email', 'unknown@unknown.com')
        user_hash = self._hash_email(user_email)
        
        response = web.StreamResponse()
        response.headers['Content-Type'] = 'text/event-stream'
        response.headers['Cache-Control'] = 'no-cache'
        response.headers['Connection'] = 'keep-alive'
        response.headers['Access-Control-Allow-Origin'] = '*'
        
        await response.prepare(request)
        
        # Legacy connection key (no mission ID)
        connection_key = f"{user_hash}_legacy"
        self.sse_connections[connection_key] = response
        
        try:
            while True:
                await asyncio.sleep(30)
                heartbeat = {"type": "heartbeat", "timestamp": datetime.now().isoformat()}
                sse_data = f"data: {json.dumps(heartbeat)}\n\n"
                await response.write(sse_data.encode())
                await response.drain()
                
        except asyncio.CancelledError:
            pass
        except Exception as e:
            BridgeLogger.log_system(f"⚠️ Legacy SSE error: {e}", self.bridge_id, "WARNING")
        finally:
            if connection_key in self.sse_connections:
                del self.sse_connections[connection_key]
        
        return response
    
    async def _handle_status(self, request):
        """PRESERVED: Status handler with ADDED mission info"""
        status_data = {
            'bridge_id': self.bridge_id,
            'status': 'active',
            'timestamp': datetime.now().isoformat(),
            'version': '2.0.0-mission-enhanced',
            'uptime_seconds': (datetime.now() - self.start_time).total_seconds(),
            'capabilities': [
                'legacy_chat',
                'mission_management',
                'context_proposals', 
                'multi_agent_messaging',
                'sse_notifications'
            ],
            # NEW: Mission stats
            'mission_stats': {
                'active_missions': len(self.mission_manager.active_missions),
                'sse_connections': len(self.sse_connections)
            }
        }
        
        return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(status_data))
    
    async def _handle_stats(self, request):
        """Enhanced stats handler with comprehensive metrics"""
        try:
            # Get enhanced metrics from BridgeLogger
            logger_metrics = BridgeLogger.get_metrics_summary()
            
            stats_data = {
                'bridge_id': self.bridge_id,
                'legacy_stats': self.message_stats,
                'active_users': len(self.active_users),
                'message_queue_size': len(self.message_queue),
                'uptime_seconds': (datetime.now() - self.start_time).total_seconds(),
                'enhanced_metrics': logger_metrics,
                'mission_info': {
                    'active_missions': len(getattr(self.mission_manager, 'active_missions', {})),
                    'missions_base_path': str(self.missions_base_path)
                },
                'agent_info': {
                    'hexaeight_agent_connected': self.hexaeight_agent is not None,
                    'git_tool_available': hasattr(self, 'git_tool') and self.git_tool is not None
                },
                'timestamp': datetime.now().isoformat()
            }
            
            return web.json_response(CamelCaseConverter.convert_keys_to_camel_case(stats_data))
        except Exception as e:
            BridgeLogger.log_system(f"Stats generation failed: {e}", "STATS", "ERROR")
            return web.json_response({
                'error': 'Stats generation failed',
                'message': str(e),
                'timestamp': datetime.now().isoformat()
            }, status=500)
    
    async def _handle_reset_stats(self, request):
        """Enhanced stats reset handler"""
        try:
            # Capture previous stats before reset
            old_message_stats = self.message_stats.copy()
            old_logger_metrics = BridgeLogger.metrics.copy()
            
            # Reset legacy stats
            self.message_stats = {
                'published': 0,
                'broker_failures': 0,
                'responses_received': 0,
                'missions_created': 0,
                'mission_messages_sent': 0,
                'last_reset': datetime.now()
            }
            
            # Reset enhanced metrics
            BridgeLogger.reset_metrics()
            
            BridgeLogger.log_system(f"All stats reset - Requests: {old_logger_metrics.get('requests_total', 0)}, Messages: {old_message_stats.get('published', 0)}", self.bridge_id)
            
            return web.json_response({
                'success': True,
                'message': 'Stats reset successfully',
                'reset_info': {
                    'previous_legacy_stats': old_message_stats,
                    'previous_requests': old_logger_metrics.get('requests_total', 0),
                    'previous_errors': old_logger_metrics.get('errors_total', 0),
                    'reset_at': datetime.now().isoformat()
                }
            })
            
        except Exception as e:
            BridgeLogger.log_system(f"Stats reset failed: {e}", self.bridge_id, "ERROR")
            return web.json_response({
                'success': False,
                'error': str(e)
            }, status=500)
    
    async def _handle_health(self, request):
        """PRESERVED: Health handler (UNCHANGED)"""
        return web.json_response({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat()
        })
    
    async def _handle_git_status(self, request):
        """Git status verification endpoint - provides detailed Git repository status"""
        try:
            # Get optional mission_id parameter
            mission_id = request.query.get('mission_id')
            
            git_status = {
                "git_tool_available": self.git_tool is not None,
                "git_initialized": hasattr(self, 'git_initialized') and self.git_initialized,
                "missions_base_path": str(self.missions_base_path),
                "timestamp": datetime.now().isoformat()
            }
            
            # Add Git tool information
            if self.git_tool:
                try:
                    git_status["git_server_url"] = getattr(self.git_tool, 'git_server_url', 'unknown')
                    git_status["git_server_agent"] = getattr(self.git_tool, 'git_server_agent_name', 'unknown')
                    git_status["current_repository"] = getattr(self.git_tool, 'current_repository', 'none')
                    git_status["current_branch"] = getattr(self.git_tool, 'current_branch', 'master')
                except Exception as e:
                    git_status["git_tool_error"] = str(e)
            
            # Check missions directory structure
            missions_status = []
            if self.missions_base_path.exists():
                git_status["missions_directory_exists"] = True
                
                for mission_dir in self.missions_base_path.iterdir():
                    if mission_dir.is_dir():
                        mission_info = {
                            "mission_id": mission_dir.name,
                            "has_git_repo": (mission_dir / ".git").exists(),
                            "has_context": (mission_dir / "context.json").exists(),
                            "has_messages": (mission_dir / "messages").exists(),
                            "messages_count": 0,
                            "git_status": "unknown"
                        }
                        
                        # Count messages
                        if mission_info["has_messages"]:
                            try:
                                messages_dir = mission_dir / "messages"
                                mission_info["messages_count"] = len([f for f in messages_dir.iterdir() if f.is_file() and f.suffix == '.json'])
                            except:
                                pass
                        
                        # Check Git status for specific mission
                        if mission_info["has_git_repo"]:
                            try:
                                import subprocess
                                result = subprocess.run(
                                    ["git", "status", "--porcelain"],
                                    cwd=mission_dir,
                                    capture_output=True,
                                    text=True,
                                    timeout=5
                                )
                                if result.returncode == 0:
                                    changes = result.stdout.strip()
                                    mission_info["git_status"] = "clean" if not changes else "modified"
                                    mission_info["git_changes"] = len(changes.split('\n')) if changes else 0
                                else:
                                    mission_info["git_status"] = "error"
                            except Exception as e:
                                mission_info["git_status"] = f"check_failed: {str(e)}"
                        
                        missions_status.append(mission_info)
                        
                        # If specific mission requested, add detailed info
                        if mission_id and mission_dir.name == mission_id:
                            git_status["requested_mission"] = mission_info
                
                git_status["total_missions"] = len(missions_status)
                git_status["missions_with_git"] = len([m for m in missions_status if m["has_git_repo"]])
                git_status["missions_with_context"] = len([m for m in missions_status if m["has_context"]])
            else:
                git_status["missions_directory_exists"] = False
                git_status["total_missions"] = 0
            
            # Add Git statistics
            if hasattr(self, 'git_stats'):
                git_status["git_statistics"] = self.git_stats
            
            # Include all missions status unless specific mission requested
            if not mission_id:
                git_status["missions"] = missions_status
            
            return web.json_response(git_status)
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Git status check failed: {e}", "GIT", "ERROR")
            return web.json_response({
                "error": "Git status check failed",
                "message": str(e),
                "timestamp": datetime.now().isoformat()
            }, status=500)
    
    async def _handle_monitoring_metrics(self, request):
        """Real-time metrics endpoint for monitoring tools"""
        try:
            # Get comprehensive metrics
            metrics = BridgeLogger.get_metrics_summary()
            
            # Add bridge-specific monitoring data
            metrics["bridge_status"] = {
                "bridge_id": self.bridge_id,
                "agent_connected": self.hexaeight_agent is not None,
                "git_available": hasattr(self, 'git_tool') and self.git_tool is not None,
                "active_missions": len(getattr(self.mission_manager, 'active_missions', {})),
                "sse_connections": len(self.sse_connections),
                "message_queue_size": len(self.message_queue),
                "processed_messages": len(self.processed_messages)
            }
            
            # Add system health indicators
            metrics["health_indicators"] = {
                "error_rate_ok": metrics["errors"]["error_rate"] < 5.0,  # Less than 5% error rate
                "avg_response_time_ok": metrics["requests"]["avg_response_time_ms"] < 500,  # Less than 500ms
                "git_success_rate_ok": metrics["git"]["success_rate"] > 95.0,  # More than 95% success rate
                "overall_health": "healthy" if all([
                    metrics["errors"]["error_rate"] < 5.0,
                    metrics["requests"]["avg_response_time_ms"] < 500,
                    metrics["git"]["success_rate"] > 95.0 or metrics["git"]["operations"] == 0
                ]) else "degraded"
            }
            
            return web.json_response(metrics)
            
        except Exception as e:
            BridgeLogger.log_system(f"Monitoring metrics failed: {e}", "MONITORING", "ERROR")
            return web.json_response({
                "error": "Metrics generation failed",
                "message": str(e),
                "timestamp": datetime.now().isoformat()
            }, status=500)
    
    async def _handle_monitoring_health(self, request):
        """Health check endpoint with detailed status for monitoring tools"""
        try:
            uptime_seconds = (datetime.now() - self.start_time).total_seconds()
            metrics = BridgeLogger.metrics
            
            # Calculate health score (0-100)
            health_score = 100
            health_issues = []
            
            # Check error rate
            total_requests = metrics.get("requests_total", 0)
            error_rate = (metrics.get("errors_total", 0) / max(total_requests, 1)) * 100
            if error_rate > 5.0:
                health_score -= min(error_rate * 2, 30)  # Cap at -30 points
                health_issues.append(f"High error rate: {error_rate:.1f}%")
            
            # Check response time
            avg_response_time = metrics.get("performance_metrics", {}).get("avg_response_time_ms", 0)
            if avg_response_time > 1000:
                health_score -= min((avg_response_time - 1000) / 100 * 5, 20)  # Cap at -20 points
                health_issues.append(f"Slow response time: {avg_response_time:.1f}ms")
            
            # Check Git operations
            git_ops = metrics.get("git_operations", 0)
            git_errors = metrics.get("git_errors", 0)
            if git_ops > 0:
                git_success_rate = ((git_ops - git_errors) / git_ops) * 100
                if git_success_rate < 90:
                    health_score -= (90 - git_success_rate) / 2  # Up to -45 points for 0% success rate
                    health_issues.append(f"Git operation failures: {git_success_rate:.1f}% success rate")
            
            # Check agent connectivity
            if not self.hexaeight_agent:
                health_score -= 15
                health_issues.append("HexaEight agent not connected")
            
            # Determine status
            if health_score >= 90:
                status = "healthy"
                status_code = 200
            elif health_score >= 70:
                status = "degraded" 
                status_code = 200
            else:
                status = "unhealthy"
                status_code = 503
            
            health_data = {
                "status": status,
                "health_score": max(0, round(health_score, 1)),
                "uptime_seconds": round(uptime_seconds, 1),
                "bridge_id": self.bridge_id,
                "components": {
                    "hexaeight_agent": "connected" if self.hexaeight_agent else "disconnected",
                    "git_tool": "available" if hasattr(self, 'git_tool') and self.git_tool else "unavailable",
                    "mission_manager": "available" if self.mission_manager else "unavailable"
                },
                "metrics_summary": {
                    "total_requests": total_requests,
                    "error_rate_percent": round(error_rate, 2),
                    "avg_response_time_ms": round(avg_response_time, 1),
                    "missions_created": metrics.get("missions_created", 0),
                    "git_operations": git_ops,
                    "git_success_rate_percent": round(((git_ops - git_errors) / max(git_ops, 1)) * 100, 1)
                },
                "health_issues": health_issues,
                "timestamp": datetime.now().isoformat()
            }
            
            BridgeLogger.log_system(f"Health check: {status} (score: {health_data['health_score']})", "HEALTH")
            
            return web.json_response(health_data, status=status_code)
            
        except Exception as e:
            BridgeLogger.log_system(f"Health check failed: {e}", "HEALTH", "ERROR")
            return web.json_response({
                "status": "error",
                "health_score": 0,
                "error": "Health check failed",
                "message": str(e),
                "timestamp": datetime.now().isoformat()
            }, status=500)
    
    # =====================================================================================
    # PRESERVED: Original lifecycle methods
    # =====================================================================================
    
    async def start(self):
        """PRESERVED: Start the bridge (ENHANCED with mission support)"""
        try:
            BridgeLogger.log_system("🚀 Starting Mission-Enhanced Bridge...", self.bridge_id)
            
            # PRESERVED: Original initialization order
            await self.initialize_hexaeight_agent()
            await self._setup_message_listener()
            await self.setup_http_server()
            
            # NEW: Start periodic cleanup task for sync timestamps
            asyncio.create_task(self._periodic_cleanup_task())
            
            BridgeLogger.log_system("✅ Mission-Enhanced Bridge started successfully", self.bridge_id)
            BridgeLogger.log_system(f"   🌐 HTTP Server: http://localhost:{self.port}", self.bridge_id)
            BridgeLogger.log_system(f"   📋 Mission API: http://localhost:{self.port}/api/missions/list", self.bridge_id)
            BridgeLogger.log_system(f"   📊 Legacy Chat: http://localhost:{self.port}/api/chat/send", self.bridge_id)
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Bridge startup failed: {e}", self.bridge_id, "ERROR")
            raise
    
    async def _send_pubsub_with_retry(self, inner_agent, pubsub_url: str, agent_name: str, message: str, message_id: str) -> bool:
        """Send PubSub message with retry logic similar to Git tool"""
        max_retries = 3
        base_delay = 1.0  # Start with 1 second
        
        for attempt in range(max_retries):
            try:
                if attempt > 0:
                    BridgeLogger.log_system(f"🔄 PubSub retry attempt {attempt + 1}/{max_retries} for {agent_name}: {message_id}", self.bridge_id)
                
                # Send PubSub message
                success = await inner_agent.publish_to_agent(pubsub_url, agent_name, message)
                
                if success:
                    if attempt > 0:
                        BridgeLogger.log_system(f"✅ PubSub succeeded on attempt {attempt + 1} for {agent_name}: {message_id}", self.bridge_id)
                    return True
                else:
                    BridgeLogger.log_system(f"❌ PubSub attempt {attempt + 1} failed for {agent_name}: {message_id}", self.bridge_id, "WARNING")
                    
                    # If this was the last attempt, log final failure
                    if attempt >= max_retries - 1:
                        BridgeLogger.log_system(f"❌ PubSub failed after {max_retries} attempts for {agent_name}: {message_id}", self.bridge_id, "ERROR")
                        return False
                    
                    # Wait before retry with exponential backoff
                    delay = base_delay * (2 ** attempt) + (0.1 * attempt)
                    BridgeLogger.log_system(f"⏳ Waiting {delay:.1f}s before PubSub retry for {agent_name}...", self.bridge_id)
                    await asyncio.sleep(delay)
                    continue
                    
            except Exception as e:
                BridgeLogger.log_system(f"❌ PubSub attempt {attempt + 1} exception for {agent_name}: {e}", self.bridge_id, "WARNING")
                
                # If this was the last attempt, log final failure
                if attempt >= max_retries - 1:
                    BridgeLogger.log_system(f"❌ PubSub failed with exception after {max_retries} attempts for {agent_name}: {message_id}", self.bridge_id, "ERROR")
                    return False
                
                # Wait before retry
                delay = base_delay * (2 ** attempt) + (0.1 * attempt)
                BridgeLogger.log_system(f"⏳ Waiting {delay:.1f}s before PubSub retry (exception) for {agent_name}...", self.bridge_id)
                await asyncio.sleep(delay)
                continue
        
        # This should never be reached, but just in case
        return False
    
    async def _send_pubsub_with_response_monitoring(self, inner_agent, pubsub_url: str, agent_name: str, git_notification: dict, message_id: str, expected_response_path: str) -> bool:
        """Send PubSub notification, poll Git every 5 seconds for 15 seconds, then retry with backoff"""
        max_retries = 3
        poll_interval = 5.0  # Check Git every 5 seconds
        max_poll_duration = 15.0  # Poll for up to 15 seconds before retry
        
        for attempt in range(max_retries):
            try:
                if attempt > 0:
                    BridgeLogger.log_system(f"🔄 Message retry {attempt + 1}/{max_retries} for {agent_name}: {message_id}", self.bridge_id)
                
                # Step 1: Send PubSub notification
                pubsub_message = json.dumps(git_notification, indent=2)
                pubsub_success = await inner_agent.publish_to_agent(pubsub_url, agent_name, pubsub_message)
                
                if not pubsub_success:
                    BridgeLogger.log_system(f"❌ PubSub failed for {agent_name}: {message_id} (attempt {attempt + 1})", self.bridge_id, "WARNING")
                    if attempt >= max_retries - 1:
                        BridgeLogger.log_system(f"❌ PubSub failed after {max_retries} attempts for {agent_name}: {message_id}", self.bridge_id, "ERROR")
                        return False
                    continue
                
                BridgeLogger.log_system(f"✅ PubSub sent to {agent_name}: {message_id} (attempt {attempt + 1})", self.bridge_id)
                
                # Step 2: Poll Git every 5 seconds for up to 15 seconds
                total_wait_time = 0
                retry_delay = 5.0 * (2 ** attempt)  # Exponential backoff for retries (5s, 10s, 20s)
                BridgeLogger.log_system(f"⏳ Polling Git every {poll_interval}s for up to {max_poll_duration}s from {agent_name}... (attempt {attempt + 1})", self.bridge_id)
                
                while total_wait_time < max_poll_duration:
                    await asyncio.sleep(poll_interval)
                    total_wait_time += poll_interval
                    
                    # Check if response file was created in Git
                    response_file_exists = await self._check_git_response_file_exists(expected_response_path)
                    
                    if response_file_exists:
                        if attempt > 0:
                            BridgeLogger.log_system(f"✅ Response file found on attempt {attempt + 1} for {agent_name}: {message_id}", self.bridge_id)
                        else:
                            BridgeLogger.log_system(f"✅ Response file found for {agent_name}: {message_id}", self.bridge_id)
                        return True
                    
                    BridgeLogger.log_system(f"🔍 Checking for response file: {expected_response_path}", self.bridge_id)
                
                # No response found after polling
                BridgeLogger.log_system(f"❌ No response file from {agent_name}: {message_id} (attempt {attempt + 1})", self.bridge_id, "WARNING")
                
                # If this was the last attempt, log final failure
                if attempt >= max_retries - 1:
                    BridgeLogger.log_system(f"❌ No response file after {max_retries} attempts for {agent_name}: {message_id}", self.bridge_id, "ERROR")
                    return False
                
                # Wait with exponential backoff before retry
                BridgeLogger.log_system(f"⏳ Waiting {retry_delay}s before retry {attempt + 2}...", self.bridge_id)
                await asyncio.sleep(retry_delay)
                    
            except Exception as e:
                BridgeLogger.log_system(f"❌ Message attempt {attempt + 1} exception for {agent_name}: {e}", self.bridge_id, "WARNING")
                
                # If this was the last attempt, log final failure
                if attempt >= max_retries - 1:
                    BridgeLogger.log_system(f"❌ Message failed with exception after {max_retries} attempts for {agent_name}: {message_id}", self.bridge_id, "ERROR")
                    return False
                
                # Continue to next attempt
                continue
        
        # This should never be reached, but just in case
        return False
    
    async def _verify_message_committed_to_git(self, git_message_path: str, message_id: str) -> bool:
        """Verify that a message file has been successfully committed to Git by reading it"""
        try:
            BridgeLogger.log_system(f"🔍 Verifying message in Git: {git_message_path}", self.bridge_id)
            
            # Use the Git MCP tool to read the file directly from Git
            if not hasattr(self, 'git_tool') or not self.git_tool:
                BridgeLogger.log_system(f"❌ Git tool not available for message verification", self.bridge_id, "ERROR")
                return False
            
            git_tool = self.git_tool
            
            # Extract mission_id from the git_message_path to determine repository
            # git_message_path format: "missions/{mission_id}/messages/{message_id}.json"
            path_parts = git_message_path.split('/')
            if len(path_parts) >= 2 and path_parts[0] == "missions":
                mission_id = path_parts[1]
                repository_name = f"missions/{mission_id}"
            else:
                BridgeLogger.log_system(f"❌ Invalid git message path format: {git_message_path}", self.bridge_id, "ERROR")
                return False
            
            # Read the file from Git to verify it exists and is valid
            read_result = await git_tool.read_file(git_message_path, repository=repository_name)
            
            if read_result.get("success"):
                content = read_result.get("content", "")
                if content and len(content) > 0:
                    try:
                        # Verify it's valid JSON
                        json.loads(content)
                        BridgeLogger.log_system(f"✅ Message verified in Git: {git_message_path} ({len(content)} chars)", self.bridge_id)
                        return True
                    except json.JSONDecodeError:
                        BridgeLogger.log_system(f"❌ Message in Git is not valid JSON: {git_message_path}", self.bridge_id, "ERROR")
                        return False
                else:
                    BridgeLogger.log_system(f"❌ Message in Git is empty: {git_message_path}", self.bridge_id, "ERROR")
                    return False
            else:
                error_msg = read_result.get("error", "Unknown error")
                BridgeLogger.log_system(f"❌ Failed to read message from Git: {git_message_path} - {error_msg}", self.bridge_id, "ERROR")
                return False
                
        except Exception as e:
            BridgeLogger.log_system(f"❌ Error verifying message in Git: {e}", self.bridge_id, "ERROR")
            return False

    async def _check_git_response_file_exists(self, expected_response_path: str) -> bool:
        """Check if the expected Git response file exists in Git repository and sync it locally if found"""
        try:
            BridgeLogger.log_system(f"🔍 Checking for response file in Git: {expected_response_path}", self.bridge_id)
            
            # Parse the response path to get mission_id and response filename
            # expected_response_path format: "missions/{mission_id}/responses/{message_id}_response.json"
            path_parts = expected_response_path.split('/')
            if len(path_parts) >= 4 and path_parts[0] == "missions" and path_parts[2] == "responses":
                mission_id = path_parts[1]
                agent_name = "unknown"  # We don't have agent name here, but it's not critical for sync
                
                # Check if response file exists in Git by trying to read it
                if not self.git_tool:
                    BridgeLogger.log_system(f"❌ Git tool not available for response check", self.bridge_id, "ERROR")
                    return False
                
                read_result = await self.git_tool.read_file(expected_response_path)
                
                if read_result.get("success"):
                    BridgeLogger.log_system(f"✅ Response file found in Git: {expected_response_path}", self.bridge_id)
                    
                    # File exists in Git, sync it to local filesystem
                    sync_success = await self._sync_response_from_git_to_local(mission_id, expected_response_path, agent_name)
                    if sync_success:
                        BridgeLogger.log_system(f"✅ Response file synced to local: {expected_response_path}", self.bridge_id)
                    else:
                        BridgeLogger.log_system(f"⚠️ Response file found in Git but sync failed: {expected_response_path}", self.bridge_id, "WARNING")
                    
                    return True
                else:
                    BridgeLogger.log_system(f"❌ Response file not found in Git: {expected_response_path}", self.bridge_id)
                    return False
            else:
                BridgeLogger.log_system(f"❌ Invalid response path format: {expected_response_path}", self.bridge_id, "ERROR")
                return False
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Error checking Git response file existence: {e}", self.bridge_id, "ERROR")
            return False
    
    # =====================================================================================
    # GIT-BASED AGENT RESPONSE METHODS
    # =====================================================================================
    
    async def _fetch_agent_responses_for_mission(self, mission_id: str) -> List[dict]:
        """Fetch all agent responses for a mission from local cache"""
        try:
            BridgeLogger.log_system(f"🔍 Fetching agent responses for mission: {mission_id}", self.bridge_id)
            
            responses = []
            responses_dir = self.missions_base_path / mission_id / "responses"
            
            if responses_dir.exists():
                for response_file in responses_dir.glob("*_response.json"):
                    try:
                        with open(response_file, 'r') as f:
                            response_data = json.load(f)
                            response_data['source'] = 'local_cache'
                            response_data['file_path'] = str(response_file)
                            responses.append(response_data)
                    except (json.JSONDecodeError, IOError) as e:
                        BridgeLogger.log_system(f"⚠️ Failed to read response file {response_file}: {e}", self.bridge_id, "WARNING")
                        continue
            
            # Sort by timestamp
            responses.sort(key=lambda x: x.get('created_at', ''), reverse=True)
            
            BridgeLogger.log_system(f"✅ Found {len(responses)} agent responses for mission: {mission_id}", self.bridge_id)
            return responses
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Error fetching agent responses: {e}", self.bridge_id, "ERROR")
            return []
    
    async def _fetch_responses_for_message(self, mission_id: str, message_id: str) -> List[dict]:
        """Fetch agent responses for a specific message"""
        try:
            all_responses = await self._fetch_agent_responses_for_mission(mission_id)
            
            # Filter responses for the specific message
            message_responses = [
                response for response in all_responses 
                if response.get('original_message_id') == message_id
            ]
            
            BridgeLogger.log_system(f"✅ Found {len(message_responses)} responses for message: {message_id}", self.bridge_id)
            return message_responses
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Error fetching message responses: {e}", self.bridge_id, "ERROR")
            return []
    
    async def _fetch_agent_specific_responses(self, mission_id: str, agent_name: str) -> List[dict]:
        """Fetch responses from a specific agent"""
        try:
            all_responses = await self._fetch_agent_responses_for_mission(mission_id)
            
            # Filter responses from the specific agent
            agent_responses = [
                response for response in all_responses 
                if response.get('agent_name') == agent_name
            ]
            
            BridgeLogger.log_system(f"✅ Found {len(agent_responses)} responses from agent: {agent_name}", self.bridge_id)
            return agent_responses
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Error fetching agent specific responses: {e}", self.bridge_id, "ERROR")
            return []
    
    async def _sync_mission_responses_from_git(self, mission_id: str) -> dict:
        """Force sync mission responses from local storage (placeholder for Git integration)"""
        try:
            BridgeLogger.log_system(f"🔄 Syncing mission responses: {mission_id}", self.bridge_id)
            
            # For now, just count existing responses
            responses = await self._fetch_agent_responses_for_mission(mission_id)
            
            return {
                'success': True,
                'synced_count': len(responses),
                'details': [f"Found {len(responses)} agent responses"]
            }
                
        except Exception as e:
            BridgeLogger.log_system(f"❌ Sync error: {e}", self.bridge_id, "ERROR")
            return {
                'success': False,
                'error': str(e)
            }
    
    async def stop(self):
        """PRESERVED: Stop the bridge (UNCHANGED)"""
        try:
            if self.site:
                await self.site.stop()
            
            if self.runner:
                await self.runner.cleanup()
            
            BridgeLogger.log_system("✅ Bridge stopped successfully", self.bridge_id)
            
        except Exception as e:
            BridgeLogger.log_system(f"❌ Bridge stop error: {e}", self.bridge_id, "ERROR")

# =====================================================================================
# PRESERVED: Original main execution
# =====================================================================================

async def main():
    """Main execution function"""
    
    parser = argparse.ArgumentParser(description='HexaEight Mission-Enhanced Centralized Bridge')
    parser.add_argument('--port', type=int, default=8080, help='HTTP server port (default: 8080)')
    parser.add_argument('--bridge-id', type=str, default='mission-bridge', help='Bridge identifier')
    
    args = parser.parse_args()
    
    bridge = MissionEnhancedCentralizedBridge(
        bridge_id=args.bridge_id,
        port=args.port
    )
    
    # Signal handling
    def signal_handler(signum, frame):
        print(f"\n💭 Received signal {signum}")
        print("🛑 Shutting down bridge...")
        asyncio.create_task(bridge.stop())
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        await bridge.start()
        
        print(f"""
🚀 Mission-Enhanced Bridge Started Successfully
===============================================
Bridge ID: {args.bridge_id}
Port: {args.port}
Version: 2.0.0-mission-enhanced

🌐 API Endpoints:
Legacy Chat:
- POST /api/chat/send
- GET  /api/chat/sse

Mission Management:
- POST /api/missions/create
- GET  /api/missions/list  
- GET  /api/missions/{{id}}/context
- POST /api/missions/{{id}}/message
- GET  /api/missions/{{id}}/messages
- GET  /api/missions/{{id}}/sse

Agent Management:
- POST /api/bridge/agents/add
- DELETE /api/bridge/agents/remove
- GET  /api/bridge/agents/user

Context Proposals:
- GET  /api/missions/{{id}}/proposals
- POST /api/missions/{{id}}/proposals/{{id}}/approve

Status & Monitoring:
- GET  /api/status
- GET  /api/stats
- GET  /health

Features:
✅ Dashboard Compatible (camelCase responses)
✅ Agent Management (Add/Remove/List User Agents)
✅ Context Proposal System  
✅ Multi-Agent Message Routing
✅ Mission-Specific SSE Streams
✅ Backward Compatible Legacy Chat
✅ Bridge-Exclusive Context Control

Dashboard URL: http://localhost:{args.port}
        """)
        
        # Keep running
        while True:
            await asyncio.sleep(10)
            
    except KeyboardInterrupt:
        print("\n👋 Shutting down bridge...")
        await bridge.stop()
    except Exception as e:
        print(f"❌ Bridge error: {e}")
        await bridge.stop()

if __name__ == "__main__":
    asyncio.run(main())
